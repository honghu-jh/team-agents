# HTML 报告模板说明

生成 revival_report_{YYYYMMDD}.html 时，按以下骨架填入真实数据：

## CSS 变量（保持不变）
```css
--primary: #1a56db;
--success: #0e9f6e;
--warn: #c27803;
--bg: #f4f6f9;
--card: #ffffff;
--border: #e2e8f0;
```

## 版块骨架

### 1. Header
```html
<div class="header">
  <div class="header-meta">阿里国际站 · 买家盘活作战室</div>
  <h1>昨日沟通未下单买家 — 盘活全流程报告</h1>
  <div class="header-sub">取数周期：{START} ~ {END} | 生成日期：{TODAY} | 账号：{ACCOUNT}</div>
</div>
```

### 2. 流程进度条（.pipeline）
5个 .pipeline-step，已完成的加 class="done"。
步骤固定：① 筛买家 → ② 背调 → ③ 痛点分析 → ④ 生成话术 → ⑤ 确认发送

### 3. 数据摘要（.stat-row）
4个 .stat-card：总沟通买家数 / 可盘活数 / 话术方案数 / 排除系统账号数

### 4. 买家卡片（.buyer-card）
每个可盘活买家一张：
- 头像取名字首字母
- 5维评分进度条（1-5 换算成 20%-100%）
- 痛点分析（.insight-block）
- 3套话术（.script-card × 3）

每套话术卡片结构：
```html
<div class="script-card">
  <div class="script-header">
    <div class="script-header-left">
      <span class="script-num">方案N</span>
      <span class="script-strategy">策略名称</span>
    </div>
  </div>
  <div class="script-body">
    <div class="script-en" id="script-N">英文话术正文</div>
    <div class="script-zh">【译】中文译文</div>
    <div class="script-actions">
      <button class="btn btn-copy" onclick="copyScript('script-N', this)">📋 复制话术</button>
      <a class="btn btn-open" href="<OneTalk深链接+replyContent=URL编码话术>" target="_blank">💬 复制并前往 OneTalk 发送</a>
    </div>
  </div>
</div>
```

OneTalk 深链接格式：
```
https://onetalk.alibaba.com/message/weblitePWA.htm
  ?activeAccountId={卖家数字ID}
  &activeAccountIdEncrypt={加密ID}
  &replyContent={URL-encodeAll(英文话术)}
```
- `activeAccountId` / `activeAccountIdEncrypt`：从 i1 chat-analysis 的 resolve-id 结果读取
- `replyContent`：对英文话术正文做完整 URL encode（含 emoji、标点、空格），预填入 OneTalk 输入框

页尾必须附加 copyScript JS 函数：
```html
<script>
function copyScript(id, btn) {
  const el = document.getElementById(id);
  const text = el ? el.innerText.trim() : '';
  if (!text) return;
  navigator.clipboard.writeText(text).then(function() {
    const orig = btn.innerHTML;
    btn.innerHTML = '✅ 已复制';
    btn.classList.add('copied');
    setTimeout(function() { btn.innerHTML = orig; btn.classList.remove('copied'); }, 2000);
  }).catch(function() {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy');
    document.body.removeChild(ta);
    const orig = btn.innerHTML;
    btn.innerHTML = '✅ 已复制'; btn.classList.add('copied');
    setTimeout(function() { btn.innerHTML = orig; btn.classList.remove('copied'); }, 2000);
  });
}
</script>
```

### 5. 排除买家（.skipped-block）
背景 #fff9f0，边框 #fcd34d，列出排除原因

### 6. 注意事项
品类对齐警告用 border-color:#f59e0b 的 .insight-block

### 7. Footer
数据来源 + 生成声明

## 布局规范（强制）

### 买家列表必须使用手风琴折叠（accordion），不得分 section 平铺

所有买家统一放在一个列表下，默认全部收起，点击展开单个，再次点击收起。
不得按优先级分成「重点跟进买家」「中度买家」「低优先买家」等独立 section 平铺展示。

手风琴骨架：
```html
<div class="buyer-accordion">
  <!-- 头部：点击展开/收起 -->
  <div class="buyer-summary" onclick="toggleBuyer('bN',this)">
    <div class="buyer-avatar av-fire|av-mid|av-light|av-low">首字母</div>
    <div class="buyer-info">
      <div class="buyer-name-row">
        <span class="buyer-name">买家名称</span>
        <span class="priority-tag p-critical|p-medium|p-light|p-low">优先级</span>
      </div>
      <div class="buyer-meta-row">
        <span class="meta-item">国旗 国家</span>
        <span class="meta-sep">·</span>
        <span class="meta-item">AliID: xxx</span>
        <span class="meta-sep">·</span>
        <!-- 必须有最近沟通时间，加 class="time" 加粗显示 -->
        <span class="meta-item time">🕐 最近沟通：YYYY-MM-DD HH:mm</span>
        <span class="meta-sep">·</span>
        <span class="meta-item">沉寂 N 天</span>
      </div>
    </div>
    <div class="buyer-right">
      <span class="badge badge-green">🟢 低风险</span>
      <span class="chevron">▼</span>  <!-- 展开时旋转180° -->
    </div>
  </div>
  <!-- 内容区：默认隐藏，展开后显示 -->
  <div class="buyer-body" id="bN">
    <!-- 5维评分 + 背调信息 + 痛点分析 + 3套话术（标签切换）-->
  </div>
</div>
```

### 最近沟通时间（必须字段）

每个买家头部必须显示 `🕐 最近沟通：YYYY-MM-DD HH:mm`，使用 `.meta-item.time` class 加粗。
不显示此字段的 HTML 视为不合格。

### 话术区必须包含完整3套，每套含
1. 方案标签切换（.tab-btn）
2. 英文话术（.script-en，带 id 供复制）
3. 中文译文（.script-zh）
4. 「📋 复制话术」按钮（onclick=copyScript）
5. 「💬 前往 OneTalk 发送」跳转链接（带 replyContent URL 参数）

### JS 函数（页尾必须包含）
```js
function toggleBuyer(id, summary) {
  var body = document.getElementById(id);
  var isOpen = body.classList.contains('open');
  document.querySelectorAll('.buyer-body').forEach(function(b){ b.classList.remove('open'); });
  document.querySelectorAll('.buyer-summary').forEach(function(s){ s.classList.remove('open'); });
  if (!isOpen) { body.classList.add('open'); summary.classList.add('open'); }
}
function switchTab(prefix, num, btn) { /* 标签面板切换 */ }
function copyScript(id, btn) { /* 复制到剪贴板，2s后还原按钮文字 */ }
```

## 完整 HTML 结构参考
- 参考本次实际生成的 revival_report_<YYYYMMDD>_week.html（v2，折叠版）
- 路径：deliveries/<YYYYMMDD>/revival_report_<YYYYMMDD>_week.html
- 该版本已包含全部5个买家手风琴折叠 + 最近沟通时间 + 3套话术（含复制/跳转）
