---
name: 国际站盘活专家
description: >-
  国际站盘活专家：自动筛选指定时间段内有沟通但未下单的买家，结合公网买家背调，分析沉寂痛点，生成多套英文盘活话术，最终以 HTML 报告呈现并在商家确认后发送。
  当用户提到以下任意内容时，必须使用本 Skill：
  盘活买家 / 唤醒沉睡客户 / 有沟通没下单 / 昨天的买家 / 未回复买家 / 沉寂买家 / 话术生成+发送 / 买家激活 / 盘活话术 / 生成盘活报告 /
  "昨天聊了没下单" / "筛选未成交买家" / "有询盘没订单" / "给未下单客户发话术" /
  revival / reactivate buyers / follow up with no-order buyers。
  即使用户没有明确说"盘活"，只要涉及"筛买家→背调→生成话术→发送"的组合链路，就触发本 Skill。
---

# 买家盘活全流程 Skill

## 1. 本 Skill 解决什么问题

帮助国际站卖家把「昨日/近期有沟通但未下单的潜在买家」从沉默转化为询盘——完整走完「筛选 → 背调 → 痛点分析 → 话术生成 → HTML 报告 → 确认发送」六个节点，中间无需人工切换工具。

---

## 2. 标准执行节点（固定顺序）

| 节点 | 执行方 | 核心动作 | 依赖 |
|------|--------|----------|------|
| i1 筛买家 | `alibaba-chat-and-analysis` | 按时间范围拉取有 IM 沟通的买家，筛除系统消息/卖家单发，输出买家快照 | 无 |
| i2 背调 | `skill-executor` + `alibaba-buyer-bgcheck` | 对 i1 圈选买家做公网+平台5维背调 | i1 |
| i3 生成话术 | `alibaba-chat-and-analysis`（接续） | 结合 i1 沟通上下文 + i2 背调结论，分析痛点、生成 3 套英文盘活话术 | i1 + i2 |
| i4 HTML 报告 | 主 Agent 直连 | 把 i1~i3 产出汇总写入 HTML 报告文件 | i3 |
| i5 确认发送 | `alibaba-chat-and-analysis`（接续） | 展示话术方案，等商家确认后通过 OneTalk 发送 | i4 |

**关键约束**：
- i1 必须是 chat-analysis，不得换工具。
- i2 背调对象 = i1 筛出的买家，背调节点不排在 chat-analysis 后（按 §5.2 规则）。
- i3 必须接续 i1 同一 chat session（用 `sessions_send` 或新 spawn 带 `[CHAT_ANALYSIS_DOWNLOAD_CONTEXT]`）。
- i4 HTML 由主 Agent 自己生成（见 §5 模板），不经 SubAgent。
- i5 发送必须等商家明确回复方案编号后才执行；禁止自动发送。

---

## 3. 入参收集

启动前，从用户 query 中提取以下参数（缺失时追问一个聚焦问题）：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `time_range` | 筛买家的时间窗口 | "昨天"→ `today - 1 day`，整日闭区间 |
| `account_scope` | 当前账号 / 全店 | 当前账号 |
| `buyer_condition` | 筛选条件 | "有 IM 沟通 + 未产生订单"（注：未下单无法通过聊天数据直接验证，需告知商家） |
| `output_format` | 是否生成 HTML 报告 | 是（默认） |

---

## 4. 多意图计划声明（必须携带）

每次 `sessions_spawn` 都带以下字段（单行 JSON）：

```
plan_id: ip_{YYYYMMDD}_revival
intent_id: <当前节点 id>
intent_plan: {"plan_id":"ip_{YYYYMMDD}_revival","intents":[{"intent_id":"i1","request_text":"筛选指定时间段有沟通买家","executor":"alibaba-chat-and-analysis"},{"intent_id":"i2","request_text":"对筛选买家做背调","executor":"skill-executor","selected_skill":"alibaba-buyer-bgcheck","depends_on":["i1"]},{"intent_id":"i3","request_text":"分析痛点并生成盘活话术","executor":"alibaba-chat-and-analysis","depends_on":["i1","i2"]},{"intent_id":"i4","request_text":"生成 HTML 盘活报告","executor":"main-agent-direct","depends_on":["i3"]},{"intent_id":"i5","request_text":"确认后发送盘活话术","executor":"alibaba-chat-and-analysis","depends_on":["i4"]}]}
```

i4（主 Agent 直连）完成后，在下次 spawn 前把 `"status":"completed"` 写入 `intent_plan` 中 i4 节点。

---

## 5. HTML 报告生成规范

i3 完成后，主 Agent 自行生成 HTML 报告。输出路径：

```
./deliveries/{YYYYMMDD}/revival_report_{YYYYMMDD}.html
```

HTML 必须包含以下版块（详细规范见 `references/html_template.md`）：

1. **Header**：报告标题、取数周期、账号名
2. **流程进度条**：5 步 pipeline，已完成节点高亮
3. **数据摘要**：沟通买家总数 / 可盘活数 / 已生成话术数 / 排除系统账号数
4. **买家列表（手风琴折叠，强制）**：
   - 所有买家统一在一个列表下，**默认全部折叠**，点击头部展开单个
   - 头部必须显示：买家名 + 优先级标签 + 国家 + AliID + **最近沟通时间（🕐 YYYY-MM-DD HH:mm，必须字段）** + 沉寂天数 + 风险标签 + 折叠箭头
   - 展开后显示：5维评分进度条 + 背调信息 + 痛点分析 + 3套盘活话术（标签切换 + 英文正文 + 中文译文 + 📋复制按钮 + 💬OneTalk跳转链接）
   - **禁止**按优先级分 section 平铺——所有买家必须在同一折叠列表内
5. **已排除买家说明**（系统账号 / 无真实询盘，如有）
6. **数据来源 Footer**

**强制约束（缺失即视为不合格）**：
- 每个买家头部必须有「🕐 最近沟通：YYYY-MM-DD HH:mm」
- 每个买家必须有完整 3 套话术，每套必须有复制按钮和 OneTalk 跳转链接
- 使用手风琴交互，不得平铺

报告不含发送按钮——发送由 i5 在 OneTalk 完成。

---

## 6. 系统账号识别与排除

以下情况判定为「无需盘活」：
- 账号名含 `Assistant` / `Bot` / `System` / `Eva Daily` 等系统关键词
- 昨日唯一消息为平台自动推送卡片（Card 类型）
- 买家无任何文本消息记录

排除的买家：在 HTML 报告和最终回复中显式说明排除理由，不静默丢弃。

---

## 7. 话术生成要求（传给 i3 的上下文）

传给 i3 chat-analysis SubAgent 的 task 必须包含：

```
执行要求：
1. 基于 i1 买家快照和 i2 背调结论，分析每个可盘活买家的沉寂痛点
2. 对每个买家生成 3 套英文盘活话术（面向买家用英文），每套含：
   - 策略名称（如"轻触问候·品类价值开场"）
   - 英文话术正文
   - 中文译文
3. 话术风格：轻接触、不施压、带明确 CTA（引导买家开口）
4. 话术文件保存至 seller_reply/<aliId>_<name>/reply_{1|2|3}.txt
5. 展示话术后等待商家确认，不自动发送
```

---

## 8. 发送确认流程（i5）

- 展示 3 套话术后，明确询问：「请回复方案 1 / 2 / 3 / 暂不发送」
- 商家回复后，通过 `sessions_send` 接续 i3 同一 chat session 执行发送
- 发送完成后输出 OneTalk 发送回执

---

## 9. 降级处理

| 场景 | 处理方式 |
|------|----------|
| i1 筛出买家为 0 | 停止流程，告知商家并建议放宽时间范围 |
| 所有买家均为系统账号 | 停止流程，建议调整筛选条件 |
| i2 背调公开信息不足 | 如实标注"信息有限"，继续生成话术（按品类通用特征） |
| 商家主营类目与话术品类不符 | 在 HTML 和确认页显式警告，让商家自行核实 |
| i5 发送失败 | 提供 OneTalk 深链接，引导商家手动发送 |

---

## 10. 禁止事项

- 禁止在商家未确认前自动发送任何消息
- 禁止对系统账号/助理账号生成话术
- 禁止在 i2 背调证据不足时补写虚假公司信息
- 禁止将 i4 HTML 生成任务委托给 SubAgent（必须主 Agent 直连）
- 禁止因"未下单"无法验证而停止流程——告知限制后继续执行

---

## Reference

- `references/html_template.md` — HTML 报告完整模板（样式 + 各版块骨架）
