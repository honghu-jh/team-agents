---
name: "[Harvest] Accio Agent 目录结构规范"
description: 指导正确构建 Accio Work 可识别的 Agent 目录结构。核心规则是 profile.jsonc 必须位于 Agent ID 根目录下，而非子目录中。适用于手动创建、脚本打包或迁移 Agent 场景，解决重启后列表不显示的问题。
created_by: main_agent
---
## Workflow
1. **确定 Agent 根目录**：在 `~/.accio/accounts/{accountId}/agents/` 下创建以 `{agentId}` 命名的文件夹（如 `MID-xxxx` 或 `DID-xxxx`）。此文件夹即为 Agent 的根目录。
2. **放置核心配置文件**：将 `profile.jsonc` **直接放置**在 Agent 根目录下（即 `agents/{agentId}/profile.jsonc`）。
   - **严禁**将其放入 `agent-core/` 或其他子目录中，否则 Accio Work 扫描时将无法识别该 Agent。
3. **创建标准子目录**：在根目录下初始化以下空目录（若不存在）：
   - `agent-core/`：存放技能源码、工具定义等核心逻辑。
   - `permissions/`：包含空的 `policy.jsonl` 和 `audit.jsonl`。
   - `runtime/`：存放 `state.jsonc`（初始状态设为 `offline`）。
   - `skills/`, `tools/`, `sessions/`, `project/`：按需创建的空目录。
4. **验证结构完整性**：确保根目录下直接可见 `profile.jsonc` 以及上述子目录。可通过 `ls agents/{agentId}/` 确认 `profile.jsonc` 不在任何子文件夹内。

## Preconditions
- 已获取合法的 `agentId` 和对应的 `profile.jsonc` 内容。
- 目标账号目录 `~/.accio/accounts/{accountId}/` 存在且可写。

## Suggestions
- 使用脚本打包时，务必先验证源目录中 `profile.jsonc` 的路径层级，确保其处于顶层。
- `profile.jsonc` 支持注释（JSONC），但需确保最终解析时无语法错误；避免使用会误删 URL 中 `//` 的正则表达式进行清理。

## Fallback / Edge Cases
- 若安装后重启 Accio Work 仍不显示 Agent，首先检查 `profile.jsonc` 是否误放入了 `agent-core/` 目录。
- 若 `profile.jsonc` 解析失败，检查是否包含非法字符或未闭合的注释；可使用支持 JSONC 的解析器验证。

## Pitfalls
- **致命错误**：将 `profile.jsonc` 放在 `agent-core/` 内。Accio Work 仅扫描 Agent ID 根目录下的 `profile.jsonc`，深层嵌套会导致 Agent "隐身"。
- **权限问题**：在 Mac 上分发安装包时，若使用 Python `zipfile` 打包，需显式设置 `external_attr` 以保留执行权限，否则 `.command` 脚本可能无法双击运行。
- **路径硬编码**：安装脚本中获取当前账号 ID 时，不应硬编码 `current-space.json` 的路径，应通过多路径候选或全局搜索方式动态定位，以兼容不同版本的 Accio Work。
