"""
gen_crm_import.py - 生成小满 CRM 客户导入表格（14 列 .xlsx）

【由技能规范重建】本脚本依据 skill 的 assets/excel_template_schema.md 与
references/crm_field_mapping.md 规范实现，把背调得到的客户 JSON 数据转换为
符合小满 CRM 导入要求的 14 列表格。

用法：
    python gen_crm_import.py --input customers.json --output 客户导入.xlsx

输入 customers.json 结构：
{
  "customers": [
    {
      "company": "示例公司",
      "country": "示例国家",
      "website": "example.com",
      "grade": "A",
      "company_note": "【推荐理由】...\\n【背调结果】...",
      "contacts": [
        {
          "name": "采购经理",
          "position": "Purchasing Manager",
          "email": "info@example.com",
          "phone": "+000 00 000 0000",
          "whatsapp": "+000 000000000",
          "facebook": "facebook.com/example",
          "instagram": "instagram.com/example",
          "priority": "P1",
          "note": "【跟进建议】..."
        }
      ]
    }
  ]
}

依赖：openpyxl（缺失时执行 pip install openpyxl）
"""

import json
import argparse
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
except ImportError:
    raise SystemExit("缺少 openpyxl，请先执行：pip install openpyxl")

# 14 列固定表头（顺序不可变，见 excel_template_schema.md）
HEADERS = [
    "公司名称", "联系人昵称", "职位", "邮箱", "电话", "WhatsApp",
    "Facebook", "Instagram", "国家地区", "官网", "客户等级", "客户来源",
    "公司备注", "联系人备注",
]

# 列宽（按字段内容长度设定，可调整）
COL_WIDTHS = {
    "A": 24, "B": 18, "C": 18, "D": 26, "E": 20, "F": 20, "G": 24,
    "H": 24, "I": 12, "J": 22, "K": 10, "L": 12, "M": 50, "N": 50,
}

HEADER_FILL = "2E7D32"
ROW_FILL_A = "E8F5E9"
ROW_FILL_B = "F1F8E9"
GRADE_COLORS = {"A": "2E7D32", "B": "F57C00", "C": "757575"}

# 联系人优先级：采购 > 市场 > 管理 > 其他
PRIORITY_ORDER = {"P1": 0, "P2": 1, "P3": 2, "P4": 3}


def _priority(contact):
    p = (contact.get("priority") or "").strip().upper()
    return PRIORITY_ORDER.get(p, 4)


def build_rows(customers):
    rows = []
    for c in customers:
        contacts = sorted(c.get("contacts", []), key=_priority)
        if not contacts:
            contacts = [{}]
        company = c.get("company", "")
        country = c.get("country", "")
        website = c.get("website") or c.get("domain", "")
        grade = c.get("grade", "")
        source = c.get("source", "自主开发")
        company_note = c.get("company_note", "")
        for i, ct in enumerate(contacts):
            # 同一公司相同联系方式只在第一个联系人行填写（去重）
            row = [
                company,
                ct.get("name", ""),
                ct.get("position", ""),
                ct.get("email", "") if i == 0 else "",
                ct.get("phone", "") if i == 0 else "",
                ct.get("whatsapp", "") if i == 0 else "",
                ct.get("facebook", "") if i == 0 else "",
                ct.get("instagram", "") if i == 0 else "",
                country,
                website,
                grade,
                source,
                company_note,
                ct.get("note", ""),
            ]
            rows.append((grade, row))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="客户 JSON 数据")
    parser.add_argument("--output", required=True, help="输出 .xlsx 路径")
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding="utf-8-sig"))
    customers = data.get("customers", data.get("companies", []))
    rows = build_rows(customers)

    wb = Workbook()
    ws = wb.active
    ws.title = "客户导入"

    header_font = Font(name="Microsoft YaHei", size=10, bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor=HEADER_FILL)
    body_font = Font(name="Microsoft YaHei", size=10)

    for col, h in enumerate(HEADERS, 1):
        letter = get_column_letter(col)
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[letter].width = COL_WIDTHS[letter]
    ws.row_dimensions[1].height = 32

    for r, (grade, row) in enumerate(rows, start=2):
        fill = PatternFill("solid", fgColor=(ROW_FILL_A if r % 2 == 0 else ROW_FILL_B))
        for col, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=col, value=val)
            cell.font = body_font
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.fill = fill
            if col == 11 and val in GRADE_COLORS:  # 客户等级列
                cell.font = Font(name="Microsoft YaHei", size=10, bold=True,
                                 color=GRADE_COLORS[val])
        ws.row_dimensions[r].height = 120

    ws.freeze_panes = "A2"

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"已生成 {len(rows)} 行（含表头共 {len(rows) + 1} 行）→ {out}")


if __name__ == "__main__":
    main()
