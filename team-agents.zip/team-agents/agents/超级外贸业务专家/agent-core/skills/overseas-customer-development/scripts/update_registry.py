"""
update_registry.py - 更新已开发客户注册表（追加 + 去重）

【由技能规范重建】本脚本依据 skill 的 SKILL.md 与 check_duplicates.py 的调用约定实现。

注册表文件（data/developed_customers.json）结构：
{
  "version": "1.0",
  "updated_at": "2026-01-01",
  "customers": [
    {"company": "...", "aliases": [...], "domain": "...", "country": "...",
     "grade": "...", "developed_at": "...", "contact_count": 1,
     "source": "自主开发", "notes": "..."}
  ]
}

用法：
    python update_registry.py --add new_customers.json
"""

import json
import argparse
from datetime import date
from pathlib import Path

DEFAULT_REGISTRY = Path(__file__).resolve().parent.parent / "data" / "developed_customers.json"


def load_registry(path=None):
    path = Path(path) if path else DEFAULT_REGISTRY
    if not path.exists():
        return {"version": "1.0", "updated_at": "", "customers": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, OSError):
        return {"version": "1.0", "updated_at": "", "customers": []}
    if "customers" not in data:
        data["customers"] = []
    return data


def _norm(s):
    return (s or "").strip().lower().rstrip("/")


def is_duplicate(candidate, registry):
    """candidate 是否已在注册表（按 company / domain / website 匹配）。"""
    cand_company = _norm(candidate.get("company"))
    cand_domain = _norm(candidate.get("domain") or candidate.get("website"))
    for rec in registry.get("customers", []):
        if cand_company and cand_company == _norm(rec.get("company")):
            return rec
        if cand_domain and cand_domain == _norm(rec.get("domain")):
            return rec
    return None


def add_customers(registry, new_customers):
    today = date.today().isoformat()
    added, skipped = [], []
    for c in new_customers:
        existing = is_duplicate(c, registry)
        if existing:
            skipped.append({"candidate": c, "matched": existing})
            continue
        rec = {
            "company": c.get("company", ""),
            "aliases": c.get("aliases", []),
            "domain": c.get("domain") or c.get("website", ""),
            "country": c.get("country", ""),
            "grade": c.get("grade", ""),
            "developed_at": c.get("developed_at") or today,
            "contact_count": c.get("contact_count", len(c.get("contacts", [])) or 1),
            "source": c.get("source", "自主开发"),
            "notes": c.get("notes", ""),
        }
        registry["customers"].append(rec)
        added.append(rec)
    registry["updated_at"] = today
    return added, skipped


def save_registry(registry, path=None):
    path = Path(path) if path else DEFAULT_REGISTRY
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--add", required=True, help="新增客户 JSON 文件")
    parser.add_argument("--registry", default=str(DEFAULT_REGISTRY))
    args = parser.parse_args()

    data = json.loads(Path(args.add).read_text(encoding="utf-8-sig"))
    new_customers = data.get("customers", data.get("companies", []))
    registry = load_registry(args.registry)
    added, skipped = add_customers(registry, new_customers)
    save_registry(registry, args.registry)

    print(f"新增 {len(added)} 家 / 跳过已开发 {len(skipped)} 家；注册表现共 {len(registry['customers'])} 家")
    for s in skipped:
        print(f"  [跳过] {s['candidate'].get('company')} → 已开发于 {s['matched'].get('developed_at')}")


if __name__ == "__main__":
    main()
