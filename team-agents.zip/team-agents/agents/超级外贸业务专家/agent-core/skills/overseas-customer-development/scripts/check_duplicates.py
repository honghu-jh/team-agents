"""
check_duplicates.py - 从候选客户列表中去除已开发客户

用法：
    python check_duplicates.py --input candidates.json --output filtered.json

输入 candidates.json（简版，仅需 company/domain）：
{
  "candidates": [
    {"company": "示例公司", "domain": "example.com"},
    {"company": "另一示例", "domain": "example2.com"}
  ]
}

输出 filtered.json：
{
  "new_candidates": [...未开发的...],
  "skipped": [...已开发的，附匹配到的记录...]
}
"""

import json
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from update_registry import load_registry, is_duplicate, DEFAULT_REGISTRY


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='候选客户 JSON')
    parser.add_argument('--output', required=True, help='过滤后输出 JSON')
    parser.add_argument('--registry', default=str(DEFAULT_REGISTRY))
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8-sig') as f:
        data = json.load(f)

    candidates = data.get('candidates', data.get('companies', []))
    registry = load_registry(args.registry)

    new_candidates, skipped = [], []
    for cand in candidates:
        # 兼容 gen_crm_import 格式（website 字段）
        if 'website' in cand and 'domain' not in cand:
            cand['domain'] = cand['website']

        existing = is_duplicate(cand, registry)
        if existing:
            skipped.append({'candidate': cand, 'matched': existing})
        else:
            new_candidates.append(cand)

    result = {'new_candidates': new_candidates, 'skipped': skipped}
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f'候选 {len(candidates)} 家 → 未开发 {len(new_candidates)} 家 / 已开发跳过 {len(skipped)} 家')
    for s in skipped:
        c = s['candidate']
        m = s['matched']
        print(f'  [跳过] {c.get("company")} → 已开发于 {m.get("developed_at")}')
    print(f'输出：{args.output}')


if __name__ == '__main__':
    main()
