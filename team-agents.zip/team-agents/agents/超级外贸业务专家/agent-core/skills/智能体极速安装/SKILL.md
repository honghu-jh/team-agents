---
name: 智能体极速安装
description: >
  将任意 Accio Work 智能体（Agent）打包为可分发的本地安装包（ZIP），并同步推送到 GitHub 仓库。
  接收方在 Mac 双击 .command、Windows 双击 .bat 即可自动安装到当前登录账号，无需命令行、无需 Python 或其他依赖。
  Use when user wants to 打包智能体/分享Agent/生成安装包/发给别人安装/一键安装/上传到GitHub/分发智能体/智能体部署。
  关键词：打包、安装包、分享Agent、一键安装、ZIP分发、GitHub上传、跨电脑安装。
version: 1.0.0
created_by: user
---

# 智能体极速安装

## 定位

把「做好的 Agent」一键变成「别人打开就能用的安装包」。

**核心使用场景**：接收方将安装命令**直接喂给 Accio Work 智能体执行**，无需打开终端、无需手动点击。

两条交付路径并行：
1. **GitHub 仓库 + 一行命令**：接收方把命令发给 Accio，Accio 自动 clone + 安装，**全程免操作**
2. **ZIP 本地安装包**：无 Git 环境时备用，Mac 双击 `.command`、Windows 双击 `.bat`

**标准安装命令（推送给接收方直接发给 Accio 执行）：**

```bash
# macOS / Linux
git clone https://github.com/{用户名}/{仓库名}.git && bash "{仓库名}/安装-苹果Mac双击我.command"
```

```powershell
# Windows
git clone https://github.com/{用户名}/{仓库名}.git && powershell -NoProfile -ExecutionPolicy Bypass -File "{仓库名}\install_helper.ps1"
```

> ⚠️ Windows 命令**直接调用 `.ps1`**，不经过 `.bat`——因为 Accio 执行 shell 命令时可直接调用 PowerShell，跳过双击 .bat 的限制。

---

## ⚠️ 核心坑位清单（必读，每条都有血泪教训）

### Mac 安装脚本（.command）

| 坑 | 现象 | 解法 |
|---|---|---|
| 执行权限丢失 | 双击弹"无法执行，没有正确访问权限" | 打包时必须用 Python `zipfile` 并设置 `external_attr = (0o755 & 0xFFFF) << 16`，不能用普通 `zip` 命令 |
| 路径硬编码 | 部分机器报"未找到 Accio Work 登录状态文件" | `current-space.json` 路径因版本/系统不同，必须多路径候选+全局搜索兜底（见 Step 5） |
| shell 转义 | Python 内嵌在 bash here-doc 里转义失控 | 把所有 Python 逻辑改为 `python3 - arg1 arg2 << 'PYEOF'` 传参方式，完全隔离 |

### Windows 安装脚本（.bat + .ps1）

| 坑 | 现象 | 解法 |
|---|---|---|
| .bat 内嵌多行 Python | 窗口直接闪退，无任何提示 | 把 Python 逻辑抽离到独立 `.py` 或 `.ps1`，`.bat` 只做一件事：调用 |
| .bat 含中文注释 | 乱码，中文字符被当命令执行 | **.bat 文件必须纯 ASCII**，中文全部放进 `.ps1`（PS5 支持 UTF-8 BOM） |
| 客户无 Python | "Python not found" | **改用 PowerShell**（Windows 7+ 全部内置），完全脱离 Python 依赖 |
| PowerShell `[ordered]@{}` | "意外标记 professional" | PS5 不支持 `[ordered]`，必须用普通 `@{}` 或手动拼 JSON 字符串 |
| .ps1 无 BOM | 中文字符串解析失败，"哈希文本不完整" | **.ps1 文件必须用 UTF-8 with BOM 写入**（Python 写文件时用 `encoding='utf-8-sig'`） |
| `ConvertFrom-Json` BOM 报错 | JSON 解析失败 | 改用 `[System.IO.File]::ReadAllText()` 读 JSON，自动剥离 BOM |
| `ConvertTo-Json` 不可靠 | PS5 嵌套对象序列化乱 | 手动拼 JSON 字符串，完全规避 `ConvertTo-Json` |

### 打包完整性

| 坑 | 现象 | 解法 |
|---|---|---|
| 调试产生多个目录 | ZIP 里只有 1 个文件（用了空目录） | 打包前必须验证源目录文件数（`find src -type f \| wc -l`），不能凭目录名猜 |
| GitHub 用户名不确定 | push 到了不存在的仓库 | 先用 GitHub API 或 MCP 确认真实 login，再构造 remote URL |
| git push 超时 | SSL 握手失败（代理问题） | 检测系统代理端口，给 git 配 `socks5://127.0.0.1:PORT` 后重试 |

---

## 执行流程

### Step 1：信息收集

从用户处获取（或自动读取）：
- 当前 Agent 的 ID（`profile.jsonc` 中的 `id` 字段）
- Agent 名称
- agent-core 路径（`~/.accio/accounts/{accountId_teamId}/agents/{agentId}/agent-core/`）
- 需要打包的 Skill 列表（读 `skills.jsonc` 的 `skills[].id`）
- GitHub Token（如需推送到 GitHub）

**自动读取当前账号：**
```bash
python3 -c "
import json
d = json.load(open('$HOME/.accio/state/current-space.json', encoding='utf-8-sig'))
print(d['accountId'], d.get('teamId',''))
"
```

### Step 2：构建打包工作目录

```
package/
├── 安装-苹果Mac双击我.command    # Mac 安装脚本（.command，权限 755）
├── 安装-Windows双击我.bat         # Windows 安装脚本（纯 ASCII）
├── install_helper.ps1             # PowerShell 安装逻辑（UTF-8 BOM）
├── agent-core/
│   ├── AGENTS.md
│   ├── BOOTSTRAP.md
│   ├── HEARTBEAT.md
│   ├── IDENTITY.md
│   ├── SOUL.md
│   └── skills/
│       ├── Skill1/SKILL.md
│       └── Skill2/SKILL.md
└── README.md
```

**排除文件**（不打包）：
- `agent-core/diary/`（私人日记）
- `agent-core/USER.md`（用户画像）
- `agent-core/MEMORY.md`（运行时记忆）
- `agent-core/skills/skills.jsonc`（运行时注册表，安装时重新生成）
- `.git/`、`__pycache__/`、`.DS_Store`

### Step 3：生成 Mac .command 脚本

关键要点：
1. 脚本开头 `cd "$(dirname "$0")"` 确保工作目录正确
2. 多路径搜索 `current-space.json`（见下方模板）
3. 从文件路径**反推** accio 根目录，不硬编码 `~/.accio`
4. 用 `python3 - arg1 arg2 << 'PYEOF'` 方式传参，避免 shell 转义地狱
5. 生成 `profile.jsonc`（含接收方真实 `accountId`）
6. 生成 `skills.jsonc`（含真实安装路径）

**多路径搜索模板：**
```bash
CURRENT_SPACE=""
for candidate in \
    "$HOME/.accio/state/current-space.json" \
    "$HOME/Library/Application Support/accio/state/current-space.json" \
    "$HOME/Library/Application Support/Accio/state/current-space.json" \
    "$HOME/Library/Application Support/Accio Work/state/current-space.json"
do
    [ -f "$candidate" ] && CURRENT_SPACE="$candidate" && break
done

# 全局兜底搜索
[ -z "$CURRENT_SPACE" ] && \
    CURRENT_SPACE=$(find "$HOME" -name "current-space.json" -maxdepth 8 \
        ! -path "*/Trash/*" 2>/dev/null | head -1 || true)
```

### Step 4：生成 Windows 脚本（.bat + .ps1）

**.bat 文件规则（铁律）：**
- 只写纯 ASCII，**绝对不能有中文**
- 只做一件事：调用 PowerShell
```bat
@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_helper.ps1"
if %errorlevel% neq 0 pause
```

**.ps1 文件规则：**
- 必须用 **UTF-8 with BOM** 写入（Python：`encoding='utf-8-sig', newline='\r\n'`）
- 不用 `[ordered]@{}`（PS5 不支持）
- 不用 `ConvertTo-Json` 序列化复杂嵌套对象（手动拼 JSON 字符串）
- 读 JSON 用 `[System.IO.File]::ReadAllText()` 而非 `Get-Content -Raw`

### Step 5：打包 ZIP（关键：权限保留）

**必须用 Python zipfile，不能用系统 zip 命令：**
```python
import os, zipfile

with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(src_dir):
        dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__']]
        for fname in files:
            fpath = os.path.join(root, fname)
            arcname = os.path.relpath(fpath, os.path.dirname(src_dir))
            info = zipfile.ZipInfo(arcname)
            fmode = os.stat(fpath).st_mode
            info.external_attr = (fmode & 0xFFFF) << 16  # 保留 Unix 权限位
            info.compress_type = zipfile.ZIP_DEFLATED
            with open(fpath, 'rb') as f:
                zf.writestr(info, f.read())
```

**打包前必须验证（防止空目录坑）：**
```bash
# 源目录文件数必须 > 10 才可信
find "$SRC_DIR" -not -path "*/.git/*" -type f | wc -l
```

**打包后验证（6 项计数）：**
```python
with zipfile.ZipFile(out_zip) as zf:
    names = [i.filename for i in zf.infolist()]
    # 检查关键文件
    checks = ['安装-苹果Mac双击我.command', '安装-Windows双击我.bat',
              'install_helper.ps1', 'agent-core/AGENTS.md']
    for c in checks:
        assert any(c in n for n in names), f"缺失: {c}"
    # 检查 .command 执行权限
    for info in zf.infolist():
        if '.command' in info.filename:
            mode = (info.external_attr >> 16) & 0xFFFF
            assert mode & 0o111, ".command 缺少执行权限！"
```

### Step 6：推送到 GitHub（可选）

```bash
# 1. 先用 GitHub MCP 确认真实用户名
accio-mcp-cli call list_github_repos | python3 -c "..."

# 2. 如果仓库不存在，用 MCP 创建
accio-mcp-cli call create_github_repo --json '{"name":"xxx","private":false}'

# 3. git init + commit + push（带 token 认证）
cd "$PACKAGE_DIR"
git init && git config user.email "agent@accio.work" && git config user.name "Accio Agent"
git add . && git commit -m "feat: {AgentName} 一键安装包"
git remote add origin "https://{login}:{token}@github.com/{login}/{repo}.git"
git push -u origin master:main 2>&1

# 4. 推送完立即清除 token（安全）
git remote set-url origin "https://github.com/{login}/{repo}.git"
```

**git push 超时处理：**
```bash
# 检测本地代理端口
for port in 7890 7897 1080 1087; do
    nc -z 127.0.0.1 $port 2>/dev/null && echo "可用端口: $port" && break
done
# 配置代理
git config --global http.proxy "socks5://127.0.0.1:PORT"
# push 完清除
git config --global --unset http.proxy
```

### Step 7：交付

**主推「Accio 直接执行」模式（接收方体验最佳）：**

输出以下两条命令，让接收方**直接发给自己的 Accio Work 执行**，一步完成：

```bash
# macOS / Linux（发给 Accio 执行）
git clone https://github.com/{login}/{repo}.git && bash "{repo}/安装-苹果Mac双击我.command"
```

```powershell
# Windows（发给 Accio 执行）
git clone https://github.com/{login}/{repo}.git && powershell -NoProfile -ExecutionPolicy Bypass -File "{repo}\install_helper.ps1"
```

**备用「ZIP 本地安装」模式（无 Git 或无网络时）：**

1. `present_files` 推送 ZIP 安装包
2. Mac：解压 → 双击 `.command` → 若弹"无法验证开发者"则右键→打开（只需一次）
3. Windows：解压 → 双击 `.bat`（`.bat` 调用 `.ps1`，无需 Python）

**安装后提醒（必说）：**
- 完全退出 Accio Work 再重新打开（不是最小化）
- 设置 → 插件 → 安装对应插件
- 连接器 → 绑定对应账号

---

## 工具清单

| 工具 | 用途 |
|------|------|
| `bash` | 读取 agent-core 文件结构、git 操作、文件复制 |
| `write` / `edit` | 生成 .command / .bat / .ps1 / README.md |
| `read` | 读取 profile.jsonc、skills.jsonc 获取 Agent 信息 |
| `python3`（内嵌） | 打包 ZIP（保留权限位）、生成 JSON 文件 |
| `accio-mcp-cli call create_github_repo` | 创建 GitHub 仓库（需 GitHub 插件） |
| `git` | commit + push |
| `present_files` | 推送 ZIP 给用户 |

---

## 输出格式

- **主交付物**：`{AgentName}-安装包.zip`（通过 `present_files` 推送）
- **辅助交付物**：GitHub 仓库链接（如用户提供了 Token）
- **使用说明**：Mac/Windows 分开说明，含首次运行的系统权限提示

---

## 禁止事项

- ❌ 不能直接复制 `profile.jsonc` 进 ZIP（`accountId` 是打包者的，装到别人机器会失效）
- ❌ 不能用系统 `zip` 命令打包（权限位会丢失）
- ❌ `.bat` 文件不能含任何中文字符（GBK/UTF-8 编码冲突必现）
- ❌ `.ps1` 不能用 UTF-8 without BOM（PS5 读中文字符串必报错）
- ❌ 不能用 `[ordered]@{}` 语法（PS5 不支持）
- ❌ 不能在 `.bat` 里内嵌多行 Python/PowerShell 逻辑（转义必崩）
- ❌ 不在 Git remote URL 里永久保存 Token（push 完立即清除）
- ❌ 打包前不验证源目录文件数，容易打出空包

---

## 质量验收标准

- [ ] ZIP 解压后文件数与源目录一致（允许排除项除外）
- [ ] `.command` 在 ZIP 内的 Unix 权限包含执行位（`mode & 0o111 == True`）
- [ ] `.bat` 文件全部 ASCII（`all(b <= 127 for b in open(.bat, 'rb').read())`）
- [ ] `.ps1` 文件头 3 字节为 UTF-8 BOM（`\xef\xbb\xbf`）
- [ ] Mac 侧：能检测到 `current-space.json` 并正确读取 accountId
- [ ] Windows 侧：PowerShell 能正确解析 JSON 并创建所有目录和文件
- [ ] 安装后 Accio Work 重启能在智能体列表看到新 Agent
