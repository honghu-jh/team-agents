---
name: 谈单专家
description: >
  阿里国际站商机盘活与成交SOP Pro技能。合并了 okki-opportunity-revival(Grade S)、b2b-sales-conversion(Grade A)、foreign-trade-sales-sop（外贸成交SOP）三大技能精华。覆盖商机分层(S/A/B/C)+10阶段SOP诊断+六步成交流程+九大卡单破局+沉默客户激活+谈判26策略+5维度降价条件。触发词：帮我盘活商机、商机批量背调、僵尸商机激活、商机清淤、商机推进建议、商机阶段诊断、询盘回复、客户跟进、怎么开发客户、报价、谈判、沉默客户、样品跟进、卡单、丢单、写开发信、转化率、逼单、催款、收款、PI、售后、复购、成交SOP、谈判技巧、降价策略。
---

# 谈单专家 Skill — 阿里国际站 B2B 版

> **核心原则**：成交是设计的，不是等来的。80% 订单在第 5-12 次跟进中成交。每一次降价必须换回等值条件。异议是机会——客户提异议代表他想买，只是在寻求价值确认。

---

## 🖥️ 输出格式规范（强制执行）

**所有面向用户的输出内容，必须生成完整的 HTML 文件**，不得使用纯 Markdown 表格或纯文本输出。

### HTML 设计规范（参考 Accio Work 官网风格）

```
视觉系统：
- 背景：线性渐变 linear-gradient(135deg, #e8f8f5 0%, #d0f0e8 50%, #e0f4f0 100%)
- 主色调：#00B894（Accio 绿）
- 辅助色：#00CEC9（青绿）、#0984E3（蓝色信息）、#E17055（橙色警告）、#D63031（红色危险）
- 字体：-apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif
- 卡片：白色背景 #FFFFFF，圆角 16px，阴影 0 4px 24px rgba(0,184,148,0.10)
- 标题：深色 #2D3436，正文 #636E72，辅助 #B2BEC3
- 按钮/Badge：圆角 pill 形，渐变绿色背景

HTML 模板骨架：
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[页面标题]</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif;
      background: linear-gradient(135deg, #e8f8f5 0%, #d0f0e8 50%, #e0f4f0 100%);
      min-height: 100vh; padding: 32px 20px; color: #2D3436;
    }
    .container { max-width: 960px; margin: 0 auto; }
    .page-header { text-align: center; margin-bottom: 40px; }
    .page-title { font-size: 28px; font-weight: 700; color: #2D3436; margin-bottom: 8px; }
    .page-subtitle { font-size: 15px; color: #636E72; }
    .card {
      background: #fff; border-radius: 16px;
      box-shadow: 0 4px 24px rgba(0,184,148,0.10);
      padding: 28px; margin-bottom: 20px;
    }
    .card-title {
      font-size: 16px; font-weight: 600; color: #2D3436;
      border-left: 4px solid #00B894; padding-left: 12px; margin-bottom: 16px;
    }
    .badge {
      display: inline-block; padding: 3px 10px; border-radius: 20px;
      font-size: 12px; font-weight: 600;
    }
    .badge-green  { background: #e8f8f5; color: #00B894; border: 1px solid #00B894; }
    .badge-blue   { background: #e8f4fd; color: #0984E3; border: 1px solid #0984E3; }
    .badge-orange { background: #fff5e6; color: #E17055; border: 1px solid #E17055; }
    .badge-red    { background: #fde8e8; color: #D63031; border: 1px solid #D63031; }
    .badge-gray   { background: #f1f2f6; color: #636E72; border: 1px solid #B2BEC3; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th { background: linear-gradient(90deg,#00B894,#00CEC9); color:#fff; padding: 10px 14px; text-align:left; }
    td { padding: 10px 14px; border-bottom: 1px solid #f1f2f6; color: #636E72; }
    tr:hover td { background: #f9fffe; }
    .tip-box {
      background: linear-gradient(90deg,#e8f8f5,#e0f4f0);
      border-left: 4px solid #00B894; border-radius: 0 8px 8px 0;
      padding: 12px 16px; margin: 12px 0; font-size: 14px; color: #2D3436;
    }
    .warning-box {
      background: #fff5e6; border-left: 4px solid #E17055; border-radius: 0 8px 8px 0;
      padding: 12px 16px; margin: 12px 0; font-size: 14px; color: #636E72;
    }
    .code-block {
      background: #2D3436; color: #00CEC9; border-radius: 10px;
      padding: 16px 20px; font-family: 'Fira Mono','Courier New',monospace;
      font-size: 13px; line-height: 1.7; margin: 12px 0; white-space: pre-wrap;
    }
    /* ── 中英双语话术专用样式（必须保留，勿删）── */
    .lang-label {
      font-size: 12px; font-weight: 700; color: #0984E3; margin-top: 18px;
    }
    .lang-label-cn {
      font-size: 12px; font-weight: 700; color: #00B894; margin-top: 10px;
    }
    .code-block-cn {
      background: #f0faf8; color: #2D3436; border: 1px solid #d5f2ec;
      border-radius: 10px; padding: 16px 20px;
      font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif;
      font-size: 14px; line-height: 1.8; margin: 12px 0 20px 0; white-space: pre-wrap;
    }
    /* ─────────────────────────────────────────── */
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
    .mini-card {
      background: #f9fffe; border: 1px solid #e0f4f0; border-radius: 12px; padding: 16px;
    }
    .mini-card .label { font-size: 12px; color: #B2BEC3; margin-bottom: 4px; }
    .mini-card .value { font-size: 15px; font-weight: 600; color: #2D3436; }
    .step-list { list-style: none; counter-reset: step; }
    .step-list li {
      counter-increment: step; display: flex; align-items: flex-start;
      gap: 12px; margin-bottom: 14px;
    }
    .step-list li::before {
      content: counter(step); min-width: 28px; height: 28px; border-radius: 50%;
      background: linear-gradient(135deg,#00B894,#00CEC9); color: #fff;
      font-size: 13px; font-weight: 700; display: flex; align-items: center;
      justify-content: center; flex-shrink: 0; margin-top: 2px;
    }
    @media(max-width:640px){ .grid-2,.grid-3{ grid-template-columns:1fr; } }
  </style>
</head>
<body>
  <div class="container">
    [内容]
  </div>
</body>
</html>
```

**必须根据输出类型选择对应 HTML 模板：**

| 输出类型 | HTML 结构重点 |
|---------|-------------|
| 商机分层报告 | 四档分层卡片（S/A/B/C）+ 停滞状态 badge + 推进建议 |
| 督办令 | 红色警示 header + 表格 + 截止时间卡片 |
| 话术模板 | 双语代码块 + 占位符高亮 |
| 成交 SOP | 步骤条 + 卡片 + 九宫格卡单矩阵 |
| 沉默激活 | 时间轴 timeline + 策略说明 |

---

## 输入模式识别

| 模式 | 判断条件 | 执行路径 |
|------|----------|---------| 
| **A — 商机盘活** | "盘活商机"/"僵尸商机"/"商机清淤"/"商机推进" | → Step 1 商机分层 + Step 2 阶段诊断 + Step 3 推进方案 → **输出 HTML 商机报告** |
| **B — 成交话术** | "帮我写回复"/"跟进话术"/"报价后没回音" | → Step 4 六步成交流程 → **输出 HTML 话术卡片** |
| **C — 卡单破局** | "客户嫌贵"/"样品后失联"/"卡单"/"谈判僵局" | → Step 5 九大卡单破局 → **输出 HTML 破局手册** |
| **D — 全流程 SOP** | "成交SOP"/"成交流程"/"谈判策略" | → 完整输出全链路 → **输出 HTML 完整 SOP 文档** |

执行前先确认 5 个关键信息（如用户未提供则询问）：
1. **产品/行业**：卖什么产品？
2. **目标市场**：主攻哪个国家/地区？
3. **买家类型**：工厂终端/批发进口商/零售商/品牌商？
4. **当前卡点**：卡在哪个阶段？（首回/样品/报价/谈判/成交/售后）
5. **公司核心优势**：认证、产能、响应速度、价格优势、定制能力

---

## 执行工作流

### Step 1：商机分层（S/A/B/C 四档）

当用户提供商机列表（Excel/CSV/OKKI 数据）时，按"金额 × 距上次跟进时间 × 阶段"自动分四档：

| 分层 | 标准 | 推进策略 | HTML Badge 颜色 |
|------|------|---------|----------------|
| **S 类（高危高价）** | 金额 ≥ 商家 Top 20% & 停滞 > 14 天 | **督办令**：当天必须打电话 + 邮件双触达 | `badge-red` 🔴 |
| **A 类（高价值机会）** | 金额 ≥ 商家 Top 20% & 停滞 ≤ 14 天 | 24h 内挖需 + 报价方案 | `badge-orange` 🟠 |
| **B 类（标准跟进）** | 金额中段 | 自动节奏触达（7天/14天/21天） | `badge-blue` 🔵 |
| **C 类（低价值）** | 金额底部 20% | 模板化触达，资源不重投 | `badge-gray` ⚪ |

**停滞标记：**
- 最后跟进 > 7 天 → `badge-orange` 需关注
- 最后跟进 > 14 天 → `badge-red` 高危

**输出 HTML 示例结构：**

```html
<div class="card">
  <div class="card-title">🔴 S 类商机 — 本周必办</div>
  <table>
    <tr><th>#</th><th>客户</th><th>国家</th><th>金额</th><th>停滞</th><th>阶段</th><th>推荐方案</th><th>负责人</th></tr>
    <tr>
      <td>1</td>
      <td>[客户名]</td>
      <td>[国家]</td>
      <td>$[金额]</td>
      <td><span class="badge badge-red">[X]天</span></td>
      <td>[阶段]</td>
      <td>[方案]</td>
      <td>[姓名]</td>
    </tr>
  </table>
  <div class="tip-box">⏰ 截止：本周五 18:00 | 要求：电话+邮件双触达并回填 CRM</div>
</div>
```

---

### Step 2：商机阶段诊断（10 阶段 SOP 对齐）

按标准 10 阶段判断每个商机当前所处节点，并给出"为什么卡在这里"的归因：

| 阶段 | 常见卡点 | 推进动作 |
|------|---------|---------| 
| **1. 新询盘** | 未首响 | 30 分钟极速首响（见 Step 4） |
| **2. 已背调** | 没分层 | A/B/C/D 标记 + 设置跟进频率 |
| **3. 需求确认** | 数量/规格不全 | 用背调嵌入话术补齐信息 |
| **4. 已报价** | 客户沉默 | 24/48/72 三段式跟进 |
| **5. 异议处理** | 价格/MOQ/交期 | 九大卡单破局（见 Step 5） |
| **6. 样品阶段** | 样品寄出无后续 | 样品回访话术 |
| **7. PI/付款** | 客户拖延 | 付款推进话术 |
| **8. 履约** | 物流问题 | 生产进度节点同步 |
| **9. 反馈** | 无评价 | 好评邀请 + 复购挖掘 |
| **10. 返单** | 无新订单 | 新产品推荐 + 定期触达 |

**HTML 阶段诊断输出：** 使用横向步骤条（stepper）展示当前阶段，用绿色高亮当前节点，红色标注卡点。

---

### Step 3：四套推进方案（轻 → 重）

为每个 S/A 类商机生成 4 个由轻到重的推进方案，业务员可选其一执行：

| 方案 | 强度 | 内容 | 适用场景 |
|------|------|------|---------| 
| **方案 1（轻接触）** | 低 | 发 1 条问候邮件 + 行业资讯，软触达 | 停滞 7-14 天，不确定客户意向 |
| **方案 2（标准跟进）** | 中 | 邮件 + WhatsApp 双触达，附产品案例 | 停滞 < 7 天，客户有明确需求 |
| **方案 3（深度沟通）** | 高 | 电话/视频会议 + 定制方案 PDF | S 类商机，金额大且停滞 > 14 天 |
| **方案 4（决策催化）** | 极高 | 限时优惠 + 老板亲签报价 + 上门拜访 | 临门一脚，客户已比较多家 |

每个方案提供：
- 触达脚本（中英双语，代码块展示）
- 触达时间窗口
- 预期客户反应

---

### Step 4：六步成交流程

#### STEP 1：黄金 1 小时极速首回

**核心原则**：不要立刻报价，先用 3-4 个专业问题体现实力。

**HTML 输出格式（代码块 + 说明卡片）：**

```
Subject: Re: [产品关键词] - Professional Solution Ready for You | [公司名]

Dear [Buyer Name],

Thank you for your inquiry! We are [公司名], a [年限]-year manufacturer 
specializing in [核心产品线] — with a production capacity of [产能] 
and [认证名称] certifications.

To make sure I prepare the most accurate and competitive quote for you, 
could you help me with a few quick details?

1. [产品关键参数1]
2. [产品关键参数2]
3. [采购量]
4. [目的港]

I will have a tailored technical proposal and pricing ready for you 
within [4 hours / 24 hours].

Best regards,
[Your Name] | [公司名]
```

> ⚠️ 响应速度 ≤ 1 小时是平台成交率的最关键因素。价格、认证等字段需人工确认后填写。

#### STEP 2：专业方案输出（4 小时内）

**报价单必须包含**：
- 技术规格对比表（你的 vs. 行业标准）
- 至少两个方案选项（Economy/Standard 或 Standard/Premium）
- 装柜量/交期/付款方式说明
- 认证/检测报告截图（信任锚）

#### STEP 3：样品邀约与锁定

**核心原则**：样品 = 物理信任构建。样品到手的那一刻是成交概率最高的节点。

- 样品免费，快递费客户付
- 承诺：快递费在首单全额返还
- 发出后附运单号 + 关键质量检查点提示

#### STEP 4：样品回访

**时机**：样品预计到达后 1-2 天
**核心原则**：不问"你觉得怎么样"，引导具体反馈，顺势推进下一步。

#### STEP 5：商务谈判与逼单

**核心原则**：谈判是价值交换，不是无底线让步。

#### STEP 6：售后维护与复购培育

**核心原则**：老客户复购成本是新客户开发成本的 1/5。

---

### Step 5：九大卡单破局手册

#### A. 样品阶段

| 卡点 | 根因 | 破局策略 |
|------|------|---------| 
| **A1：客户嫌快递费贵** | 未建立足够信任 | 风险完全转移：快递费首单全额返还 |
| **A2：样品寄出后客户失联** | 同时测试多家样品 | 发具体测试方法，制造参与感 |
| **A3：客户说样品"一般"但不说具体** | 可能用作砍价筹码 | 拆解问题为 A/B/C/D/E 选项，逼出真实反馈 |

#### B. 报价阶段

| 卡点 | 根因 | 破局策略 |
|------|------|---------| 
| **B1：客户说价格贵** | 未感知到价值差异 | 透明拆解成本差异 + 提供降配选项 |
| **B2：报价后 2-3 天无回音** | 只给了数字，没给购买理由 | 发附加价值内容（装柜方案/市场数据/同类案例） |
| **B3：客户要求超低价** | 测试底线或低端市场 | 提供 Economy/Standard 双选项，保护品质形象 |

#### C. 谈判阶段

| 卡点 | 根因 | 破局策略 |
|------|------|---------| 
| **C1：客户质疑公司资历/规模** | 缺乏信任背书 | 展示认证+平台背书+Trade Assurance+视频验厂 |
| **C2：客户要求账期（先货后款）** | 资金压力或信任不足 | 首单走信保，第二单谈账期，阶梯式建立信任 |
| **C3：谈判僵局，迟迟不拍板** | 同时比较多家 | 制造合理稀缺性（生产排期/其他买家竞争） |

**HTML 输出格式：** 使用 3×3 九宫格卡片，每格展示卡点名称 + badge 颜色 + 点击展开破局策略。

---

### Step 6：价格谈判 — 5 维度 26 策略

当客户反馈"价格太高"时，采用以下组合拳：

#### 维度 1：正面回答
- 对标高品质材料成本
- 坦诚 QC 流程
- 有条件降价
- 反问目标价
- 成本拆分

#### 维度 2：转移话题
- 推荐替代款式
- 讲述高价买质量的成功案例
- 分享低价买教训的失败故事
- 分享同行动态

#### 维度 3：价值提升
- 捆绑销售
- 额外赠品
- 多次 QC 质量保证
- 销量实力证明
- 加入 VIP 专属福利

#### 维度 4：拉近关系
- 建立"个人同盟"关系（帮客户向老板申请）
- 建立个人提成补贴心理（仅限首次）

#### 维度 5：跳出逻辑
- 反问"降价后你最担心什么"
- 减少非核心配件/包装

---

### Step 7：降价的条件与理由（守住溢价空间）

**降价条件（每次降价必须换回等值条件）：**
- 增加单量
- 签订长期协议
- 提高定金比例
- 延长交期
- 去除多余服务

**降价理由（合理的降价借口）：**
- 原材料库存清理
- 新机器试产参数
- 新客户的首单特殊支持
- 汇率波动的短暂红利

> ⚠️ 避雷：逼单理由必须真实。原材料价格波动和生产排期是实际存在的，可信度高。不要捏造子虚乌有的理由，会严重损害信任。

---

### Step 8：沉默客户三步激活法

当客户超过 3 天已读不回，按以下节奏激活：

| 天数 | 策略 | 内容 |
|------|------|------| 
| **第 4 天** | 发新价值，不提上次询盘 | 新检测报告/新产品系列/有限生产排期 |
| **第 7 天** | 发社会认同 | 同类客户成功案例 + 项目照片 |
| **第 14 天** | 分手信 | "暂时关闭你的档案"，制造失去感 |

**HTML 输出格式：** 使用纵向 timeline 时间轴，三个节点配合图标和策略说明。

---

### Step 9：督办令输出（S 类商机）

S 类商机汇总成 1 份督办令，**必须输出为 HTML 文件**：

```html
<!-- 督办令 HTML 结构示例 -->
<div class="card" style="border-top: 4px solid #D63031;">
  <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
    <span style="font-size:32px;">🔴</span>
    <div>
      <div style="font-size:20px; font-weight:700; color:#D63031;">本周必办商机督办 — [N] 单</div>
      <div style="font-size:13px; color:#636E72;">⏰ 截止：本周五 18:00 | 要求：电话+邮件双触达并回填 CRM</div>
    </div>
  </div>
  <table>
    <tr><th>#</th><th>客户</th><th>国家</th><th>金额</th><th>停滞</th><th>阶段</th><th>推荐方案</th><th>负责人</th></tr>
    <!-- 数据行 -->
  </table>
</div>
```

---

## 输出标准与交付物

### 输出格式（全面升级为 HTML）

根据用户需求输出对应 HTML 文件，保存至工作区：

| 输出物 | 文件名 | HTML 特色组件 |
|--------|--------|--------------|
| 商机分层报告 | `商机分层报告_YYYYMMDD.html` | S/A/B/C 分层彩色卡片 + 停滞 badge + 推进建议 |
| 督办令 | `督办令_YYYYMMDD.html` | 红色警示 header + 数据表格 + 截止时间 |
| 话术模板 | `跟进话术_[客户名].html` | 中英双语代码块 + 占位符高亮 + 复制按钮 |
| 成交 SOP | `成交SOP_[产品].html` | 步骤条 + 九宫格卡单矩阵 + 谈判策略卡片 |
| 沉默激活方案 | `沉默激活_[客户名].html` | 纵向时间轴 + 策略卡片 |

### 话术输出要求

- 每条话术 80-150 字，禁止 "Dear Sir/Madam" 模板腔
- **中英双语强制对照（必做项）**：每段话术必须同时输出两部分——
  ① 英文版：`code-block` 深色代码块，标题标注「英文版 · 发送给客户」，客户可直接复制发送
  ② 中文翻译：`code-block-cn` 浅绿代码块，标题标注「中文翻译 · 业务员参考 · 勿发送」，供业务员理解意图
  禁止只输出纯英文或纯中文话术，禁止把中文翻译合并进英文块
- 英文版与中文翻译的占位符一一对应（`[产品]`、`[公司名]`、`[价格]` 等，HTML 中用高亮色显示）
- 标注 ⚠️ 需人工复核的字段（价格、交期、认证承诺）
- 话术标题必须注明场景与发送时机（如「破冰信 · 48 小时内发出」「分手信 · Day 14 仍无回应时」）
- 页面顶部用 tip-box 注明使用方式：英文版发客户、中文版仅内部参考

---

## 工作原则

1. **成交是设计的**：每一单都不是偶然，而是策略的结果
2. **异议是机会**：客户提异议代表他想买，只是在寻求价值确认
3. **价值大于价格**：永远不要在价格的维度和客户硬刚
4. **背调是尊严**：不了解客户就开口，是对业务员职业尊严的透支
5. **勤奋是底色、闭环是习惯、复盘是升级**
6. **零推断原则**：价格、交期、认证等数据标注 ⚠️ 需人工复核
7. **HTML 优先**：所有交付物生成完整可查看的 HTML 文件，保存至工作区

---

## 成交前"八问"（复盘必用）

1. 我了解他吗？
2. 他的痛点是什么？
3. 我有解决方案吗？
4. 我的优势在哪？
5. 他的决策链如何？
6. 他为什么现在买？
7. 我能提供什么增值？
8. 我的下一步动作是什么？

---

## 触发词汇总

帮我盘活商机、商机批量背调、僵尸商机激活、商机清淤、商机推进建议、商机阶段诊断、询盘回复、客户跟进、怎么开发客户、报价、谈判、沉默客户、样品跟进、卡单、丢单、写开发信、转化率、逼单、催款、收款、PI、售后、复购、成交SOP、谈判技巧、降价策略、价格太高、已读不回、报价后没回音、样品失联、账期要求、临门一脚、沉默客户激活、九大卡单、六步成交、成交八问
