---
name: material-publish-flow
description: |
  国际站（Alibaba.com）素材包发品技能：用户提供产品图片/素材（聊天附件、URL 或本地文件）时，AI 解析素材自动补全类目、属性、SKU 与商详装修（可选 AI 生图），将商品发布为草稿或正式上架，输出草稿编辑链接与质量分。用于卖家快速用少量素材把商品发到草稿箱或直接上架。
  触发场景：
  - "帮我发布一个产品（到草稿箱/上架）"，附产品图片/素材包/链接
  - "用这些图片发品"、"AI 发品"、"素材发品"、"发布商品到草稿"
  - 用户上传 1-N 张产品图（白底图/场景图/详情图）并要求创建商品
  - 用户提供 Product.xlsx 或素材包要求发品
  不触发：修改/优化已有商品的价格、规格、标题（走 reference-trade-copy 或 alibaba-product-optimization）、只生成商品图片（image-prompt-guide）、仅把已有草稿上线而无字段诉求（草稿发品直连 product-publish）。
---

# 素材包发品流程

把用户提供的产品素材（图片等）经 AI 解析、自动补全商品信息后，发为草稿或正式上架。核心链路：素材采集 → 云端解析 → 轮询取回 product.json → 渲染 Excel 沉淀 → 发品 → 汇总输出。

## 前置准备

- 确认发品意图与目标：发布到**草稿箱**（`publish_type=draft`）还是**正式上架**（`publish_type=online`）。用户明确说"草稿箱/草稿"→ draft；说"上架/发布上线"→ online；未明确时默认 draft 并询问。
- 确认素材来源：聊天附件图片（下载到工作目录）/ URL / 本地文件。
- 创建独立工作目录：`analysis_<YYYYMMDD_HHMMSS>/`，素材图片放目录根，后续产物都在其中。

## 执行流程

### Step 1：确认发品方式与方案（ask_user）

发品方式（二选一，文案固定）：
1. **AI 发品（含图片生成）**：AI 智能解析素材，自动补全类目、属性、SKU 和商详装修，支持按指令改属性、AI 生图。适合图片不足或素材零散。
2. **极简发品（不含图片生成）**：跳过商详装修与 AI 生图，快速发布、消耗更低。适合已备齐 5 张商品图与若干商详图。

选 AI 发品后继续选方案（decorationPlan）：
- 【全能精装版】→ `premium`（生成/优化 6~10 张图，主推款）
- 【经济简装版】→ `standard`（生成/优化 3~5 张图，普通款/测款）
- 【基础版】→ `none`（基于原素材生成结构化详描，快速上品）
- 极简发品 → `minimal`（不生成图）

### Step 2：素材采集（extract → CDN 化 → user_query → 打包上传）

```bash
# 1) 素材提取（图片/PDF/文本），产出 result/image_list.json + result/extracted_texts.json
workctl publishflow material-extract --work_dir <工作目录> --format json

# 2) CDN 化：读取 result/image_list.json 的本地文件名数组，对每项调用 read 工具
#    读取 <工作目录>/result/<文件名>，取得返回的 https:// CDN URL，
#    按原顺序覆盖写回 result/image_list.json

# 3) 写用户诉求（单字段 user_query，云端自行解析融合）
#    result/user_query.json → {"user_query": "<用户原始诉求文本>"}

# 4) 写发品方案
#    result/decoration_plan.json → {"decorationPlan": "<premium|standard|none|minimal>"}

# 5) 打包上传 OSS，得到 MATERIAL_PATH（data 或顶层 ossUrl）
workctl publishflow material-collect --work_dir <工作目录> --format json
```

规则：
- **禁止**用 Write 工具伪造 `extracted_texts.json` / `image_list.json`；Agent 写文件仅限 CDN 化覆盖 image_list.json、user_query.json、decoration_plan.json
- 附件图片先下载到工作目录根再 extract（保持原始文件名）
- 上传返回空 ossUrl → 判定异常，停止

### Step 3：提交云端素材处理

```bash
workctl icbu product analyze-merge-optimize-material --ossUrl "<MATERIAL_PATH>" --extInfo '{"decorationPlan":"<方案>"}' --format json
```

- 返回 `data` 即 uniqueKey（字符串），记为 MATERIAL_UNIQUE_KEY
- `success:true` 但 data 为空 → 判定提交异常，停止

### Step 4：轮询解析结果，下载 product.json

```bash
workctl publishflow fetch-material-result --uniqueRequestId "<MATERIAL_UNIQUE_KEY>" --out <工作目录>/product.json --scene initial --format json
```

- `status=pending_dependency` → 按 `retry_after_ms` 等待后重试相同命令（分次驱动，非脚本循环；上限约 25 次）
- `ready=true` → 完成，product.json 由命令原样落盘（itemCount 为商品数）
- 低噪音提示：进入轮询时提示一次"素材解析已提交，预计需要几分钟，我会持续等待并在完成后继续发品。"；每 5 次仍处理中最多输出一行进度
- **禁止**手工调用 list-material-analysis-result、禁止手工下载 OSS JSON

### Step 5：渲染 Product.xlsx 并行沉淀

```bash
workctl publishflow render-product-excel --in <工作目录>/product.json --out <工作目录>/Product.xlsx --format json
```

- 仅作并行沉淀展示，不参与首次发品入参；禁止主 Agent 依据原始 query 回头核对/回填/编辑任何字段

### Step 6：发品

```bash
workctl publishflow publish-from-json --input <工作目录>/product.json --publish_type <draft|online> --format json
```

- 用户要求发草稿必须显式传 `--publish_type draft`，不得省略
- 成功 item 返回纯数字 productId + 质量分（finalScore/lowScore/deductReasons）
- 失败 item 带 errorCode/error/itemJsonPath → 进入 completeness_check 补全流程（最多 3 轮，用 itemJsonPath 的 JSON 补全字段后重提）

### Step 7：汇总输出

- 草稿成功：逐个透出草稿编辑链接 `https://post.alibaba.com/product/publish.htm?itemId=<productId>&pubAction=draft`
- 质量分：`lowScore=false` → "质量分 X/5，无扣分项"；`lowScore=true` → 列 deductReasons；`lowScore=null` → 显示 qualityScoreMessage
- 单品成功：`Product.xlsx` 更名 `<productId>.xlsx`，告知"商品信息已保存为 {productId}.xlsx"；多品用 render-product-excel 从各 item JSON 重渲染
- 全部 item 成功且用户意图仅发品（非"创建模版"）→ 不引导保存模版步骤；有失败 item 必须列出失败项与原因

## 无凭证不交付（强制）

- `taskId`/`requestKey` 只代表已提交；必须拿到 productId、终态 URL 或明确 success 回执才能说"已完成/已发布"
- 工具结果 truncated/超时/报错时，不基于残缺内容补写数值、表格或结论
- 输出 URL 必须逐字来自工具原始返回，不得编造或改域名

## 错误处理

| 场景 | 处理 |
|------|------|
| material-extract 失败/空结果 | 检查素材文件是否存在、是否可读，告知用户具体原因 |
| 上传/提交返回空 data | 判定异常停止，展示原始返回 |
| 轮询超上限仍 pending | 告知仍在处理，给出原 status 命令，不重新提交 |
| publish 部分失败 | 成功项正常呈现，失败项走补全流程并表格列原因 |
| 用户指定 .xlsx/.docx/.pdf 输出 | 必须用真实办公格式，不可用 CSV/文本替代（除非用户接受降级） |
