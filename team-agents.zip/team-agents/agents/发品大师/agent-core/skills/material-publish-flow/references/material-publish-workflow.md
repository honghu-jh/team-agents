# 素材包发品详细工作流（含实战案例）

> 本文档记录完整命令序列与一次真实案例（白色 ABS 工业安全帽：3 张附件图片，AI 发品 premium 方案，发布到草稿箱，productId 1601936687782）。

## 1. 完整命令序列

### 1.1 准备工作目录并下载附件图片

```bash
WD="<工作区>/analysis_$(date +%Y%m%d_%H%M%S)" && mkdir -p "$WD"
# 附件图片从 CDN URL 下载到工作目录根，保持原文件名
curl -sSL -o "$WD/3.jpg" "https://sc02.alicdn.com/kf/H04b98bd2250e4d3cb7a1ab8561c4be77N.jpg"
curl -sSL -o "$WD/29.jpg" "https://sc02.alicdn.com/kf/H819ec7a85fc744c98a50b28fa6d7f01ei.jpg"
curl -sSL -o "$WD/W-1000-A.jpg" "https://sc02.alicdn.com/kf/He616eacb4d7942df9951844b63240642T.jpg"
```

### 1.2 素材提取

```bash
workctl publishflow material-extract --work_dir "$WD" --format json
# 期望：imageCount=N，产物在 $WD/result/
```

### 1.3 CDN 化 image_list.json

1. `read $WD/result/image_list.json` 得到本地文件名数组（如 `["29.jpg","3.jpg","W-1000-A.jpg"]`）
2. 对每个文件名 `read $WD/result/<文件名>` 取得其 https:// CDN URL
3. 按原顺序覆盖写回 `$WD/result/image_list.json`（内容为 URL 数组）

### 1.4 写 user_query 与 decoration_plan

```json
// $WD/result/user_query.json
{"user_query": "帮我发布一个产品在草稿箱，使用上传的3张白色工业安全帽产品图片，发布为草稿（不正式上架）。"}
```

```json
// $WD/result/decoration_plan.json
{"decorationPlan": "premium"}
```

### 1.5 打包上传 OSS

```bash
workctl publishflow material-collect --work_dir "$WD" --format json
# 返回 ossUrl，如 https://skill.accio.com/product-publish/xxx_material_upload.zip
```

### 1.6 提交云端素材处理

```bash
workctl icbu product analyze-merge-optimize-material --ossUrl "https://skill.accio.com/product-publish/xxx_material_upload.zip" --extInfo '{"decorationPlan":"premium"}' --format json
# 返回 data = uniqueKey，如 6b91ebe738644b9fa8d3cc58864cc810
```

### 1.7 轮询取回 product.json

```bash
workctl publishflow fetch-material-result --uniqueRequestId "6b91ebe738644b9fa8d3cc58864cc810" --out "$WD/product.json" --scene initial --format json
# pending_dependency → sleep retry_after_ms 后重试相同命令；ready=true 完成
```

### 1.8 渲染 Product.xlsx

```bash
workctl publishflow render-product-excel --in "$WD/product.json" --out "$WD/Product.xlsx" --format json
```

### 1.9 发品（草稿）

```bash
workctl publishflow publish-from-json --input "$WD/product.json" --publish_type draft --format json
# 成功返回：{"failed":0,"publishType":"draft","results":[{"productId":1601936687782,...,"finalScore":4.9,"lowScore":false}]}
```

### 1.10 更名沉淀

```bash
mv "$WD/Product.xlsx" "$WD/1601936687782.xlsx"
```

## 2. 发品结果示例

```json
{
  "failed": 0,
  "publishType": "draft",
  "results": [
    {
      "productId": 1601936687782,
      "finalScore": 4.9,
      "lowScore": false,
      "draftUrl": "https://post.alibaba.com/product/publish.htm?itemId=1601936687782&pubAction=draft"
    }
  ]
}
```

## 3. 用户可见输出模板

| 项目 | 结果 |
|------|------|
| 商品 ID | 1601936687782 |
| 发布状态 | 草稿（draft） |
| 质量分 | 4.9/5，无扣分项 |

**草稿编辑链接**：[点击编辑草稿](https://post.alibaba.com/product/publish.htm?itemId=1601936687782&pubAction=draft)

商品信息已保存为 1601936687782.xlsx，可后续用于编辑或作为模版复用，可用 excel 快速发品。

## 4. 实战要点

| 要点 | 说明 |
|------|------|
| 发草稿必须传 `--publish_type draft` | 省略会默认其他行为，用户要求草稿时显式传 |
| 轮询分次驱动 | 每次按返回的 retry_after_ms 等待，不写脚本死循环；最多约 25 次 |
| CDN 化必须用 read 工具 | 本地文件名 → read 返回 https URL → 覆盖 image_list.json；禁止伪造 |
| 素材解析成功后 product.json 只读 | 渲染 Excel 与发品都以该文件为唯一输入，不回填字段 |
| 质量分展示 | lowScore=false→无扣分项；true→列 deductReasons；null→显示 qualityScoreMessage |
| 失败 item 补全 | 用 itemJsonPath 的 JSON 补全必填字段后重提，最多 3 轮 |
