# Prompt模板库

> 使用时将 [方括号] 内容替换为实际产品信息，保持英文输出。
> **配置驱动**：先读取 `references/brand-config-template.md`。类目代码决定配色/场景/材质风格；公司名/工厂数据/认证/MOQ/交期等字段用于替换占位符。config 中未填的字段才向用户临时询问。

---

## 模板1：首图B2B化（最常用）

```
Transform this product image into a professional B2B procurement promotional banner. 
Keep the [product_color_and_name] as the hero product, prominently displayed in the center-left area. White background.

Add the following B2B buyer procurement elements:

1. **Top header bar** in [theme_color]: "[category_name] | OEM & Wholesale Supplier"

2. **MOQ badge** upper-left corner: Bold green shield badge "MOQ: [moq] Units" with a factory/warehouse icon

3. **Key spec callouts** — [3-4] floating label tags pointing to different parts of the product:
   - Pointing to [part_1]: "[spec_1]"
   - Pointing to [part_2]: "[spec_2]"
   - Pointing to [part_3]: "[spec_3]"

4. **Color/variant options** right side: [count] small product silhouettes showing color variants — [color_1], [color_2], [color_3] — with label "Custom Color Available"

5. **Certification row** bottom-left: [cert_1] | [cert_2] | [cert_3] | [cert_4] badges in a clean horizontal strip

6. **Tiered pricing table** bottom-right (clean card style):
   | Qty | Price |
   | [MOQ]–[qty_1] pcs | $[price_1] |
   | [qty_1]–[qty_2] pcs | $[price_2] |
   | [qty_2]+ pcs | $[price_3] |

7. **Bottom CTA strip** in [theme_color]: "✔ Free Sample Available  |  ✔ OEM Logo Accepted  |  ✔ [lead_time_days]-Day Lead Time  |  ✔ Global Shipping"

8. **Trust badges**: ⭐[rating]/5 Rating | [client_count]+ B2B Clients | Trade Assurance | [warranty_years]-Year Warranty

Style: Clean, modern, professional. [theme_color], white, [accent_color] color palette. Trustworthy B2B e-commerce feel suitable for Alibaba.com listing.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板2：卖点图（产品细节特写）

```
Product detail feature image for B2B e-commerce.
Main subject: Close-up detail shot of [产品名称], showing [材质/工艺/结构特点].
Layout: Split composition — left side product macro detail, right side feature callout icons with text areas.
Callout arrows pointing to key features: [卖点1], [卖点2], [卖点3].
Background: Clean white or very light neutral gray.
Style: Technical product photography with infographic elements, professional and clean.
Lighting: Even, shadow-free studio lighting to show material texture clearly.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板3：场景图（使用场景展示）

```
Product application scene image for B2B catalog.
Subject: [产品名称] in realistic use environment — [使用场景描述].
Style: Lifestyle commercial photography, showing product in professional context.
Atmosphere: [类目对应场景氛围].
Include subtle brand presence.
Multiple product variants or color options displayed if applicable.
Background: [场景背景描述], not overly busy.
Professional photography quality, well-composed, natural lighting.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板4：公司实力图

```
Company strength showcase banner for Alibaba.com.
Layout: Grid of 4-6 data cards / stat blocks showing company credentials.
Visual elements: Factory exterior photo (modern, large-scale) as background (30% opacity overlay).
Data cards content areas for: [建厂年份] Years Experience / [工厂面积]㎡ Factory / [员工数] Employees / [产能] Annual Output / [出口国] Countries Exported / [认证数] Certifications.
Each card has icon + number + label.
Color scheme: Deep navy blue or dark green with white text — professional, trust-building.
Style: Corporate infographic, B2B marketing collateral.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板5：服务/认证图

```
Services and certifications showcase image for B2B supplier profile.
Top section: Row of certification badge icons — [认证列表: ISO/CE/FDA/ROHS etc.].
Middle section: Service icons grid — OEM/ODM Custom, Fast Sample, Custom Packaging, Global Shipping, After-sales Support.
Bottom section: Partner brand logos strip or quality inspection process flow.
Color scheme: Professional blue-white or dark charcoal-gold, conveying reliability.
Style: Clean corporate design, trust signals, B2B focused.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板6：CTA行动号召图

```
Call-to-action promotional banner for Alibaba.com product listing.
Layout: Bold CTA-focused design.
Headline area: "Get Free Sample" or "Contact Us for Best Price" — large, bold typography.
Product image: [产品名称] thumbnail, bottom-right corner.
Benefit icons (3 items): Free Sample Available / [交期] Fast Delivery / Custom Logo Service.
Urgency element: Limited time offer badge or "Send Inquiry Now" button graphic.
Color: High contrast — deep blue/orange or red/white, energetic and action-driving.
Style: Promotional e-commerce banner, conversion-optimized.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板7：工厂背书图

```
Create a professional B2B supplier capability banner combining a [product_name] product with real factory scenes.

Layout: Dark navy blue background for premium feel.

TOP HEADER: White bold text "[brand_name] — [years]+ Years Professional Manufacturer | Factory Direct Supply"

MAIN AREA: Split into 2 columns:
LEFT (60%): Large hero shot of the [product_description], clean product display with soft shadow. 
Below the product: key specs in white text:
• [spec_1]
• [spec_2]
• [spec_3]
• [spec_4]

RIGHT (40%): 4 factory scene thumbnails in a 2x2 grid:
- Top-left: Factory building exterior
- Top-right: Production workshop
- Bottom-left: Office/R&D team
- Bottom-right: Warehouse/shipping area

Each thumbnail has a small white label:
• "[area] sqm Factory"
• "[count]+ Production Lines"
• "[count]+ R&D Engineers"
• "[count] pcs Monthly Capacity"

BOTTOM STRIP in gold/amber: "✔ ISO 9001 Certified | ✔ [cert_1] / [cert_2] / [cert_3] | ✔ OEM & ODM Accepted | ✔ Trade Assurance"

Style: Premium, trustworthy. Navy blue, white, gold accents.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板8：模特使用场景图

```
Create a lifestyle B2B product banner for a [product_name]. White and light gray background. Warm, aspirational style.

TOP: Clean sans-serif headline in dark charcoal: "[value_proposition]"
Subtext in navy: "Trusted by [count]+ [industry] Brands & Distributors Worldwide"

MAIN AREA: 3 lifestyle scene panels side by side:

Panel 1 — "[scene_1_name]":
[scene_1_description: person + action + background + lighting]
Caption: "[scene_1_context]"

Panel 2 — "[scene_2_name]":
[scene_2_description]
Caption: "[scene_2_context]"

Panel 3 — "[scene_3_name]":
[scene_3_description]
Caption: "[scene_3_context]"

Each panel has a small tag: "B2B Bulk Order Available"

BOTTOM INFO BAR in navy blue:
Left: Product image thumbnail + "MOQ: [moq] pcs from $[price]/pc"
Center: ⭐[rating]/5 | [client_count]+ Global Clients | [warranty]
Right: Orange CTA button "Request Free Sample →"

Style: Clean, modern lifestyle photography. Warm tones, natural lighting. Professional yet approachable.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板9：生产流程图

```
Create a professional B2B production process & quality control banner for a [product_name]. Clean white background.

TOP HEADER in dark green: "From Raw Material to Your Door — Full Quality Control"
Subtext: "Every unit inspected before shipment | OEM orders welcome"

MAIN AREA: A horizontal process flow showing 5 steps with icons:

Step 1 — [Factory icon] "Raw Material QC"
Text: "[material_description]"

Arrow →

Step 2 — [Gear icon] "Precision Manufacturing"
Text: "[production_line_description]"

Arrow →

Step 3 — [Microscope icon] "Quality Inspection"
Text: "[inspection_standard]"

Arrow →

Step 4 — [Box icon] "Custom Packaging"
Text: "OEM box printing available"

Arrow →

Step 5 — [Plane icon] "Global Shipping"
Text: "Door-to-door, [lead_time_days]-day lead time"

BOTTOM: 
Left — Certification badges: [cert_list]
Right — Factory showroom/sample room photo + "Visit Our Factory — Samples Ready"

BOTTOM STRIP in dark green: "Factory Direct = Best Price + Full Control | MOQ [moq]pcs | Custom Logo | Worldwide Export"

Style: Industrial-professional, infographic feel. Dark green, white, charcoal.
Image ratio: 1:1, 1024x1024px.
```

---

## 模板10：产品集合图

```
Create a professional B2B wholesale product collection banner. [bg_color] background. Clean, modern layout.

TOP: [header_color] header bar with white text: "[series_name] | OEM & Wholesale Solutions"

MAIN AREA: Show these 2 products side by side, large and clear:
- LEFT: [product_1_description]
- RIGHT: [product_2_description]

Each product has a label card below it:
LEFT label:
• [product_1_name]
• [spec_options]
• [material]
• MOQ: [moq] pcs

RIGHT label:
• [product_2_name]
• [spec_options]
• [material]
• MOQ: [moq] pcs

B2B elements:
- Top-right corner: [color] badge "[customization_note]"
- Bottom strip: 4 icons — [[icon_1]] [[icon_2]] [[icon_3]] [[icon_4]]
- Small text: "Free Sample | [lead_time_days]-Day Lead Time | Global Shipping"

Color palette: [primary_color], [secondary_color], white. Professional B2B feel.
Image ratio: 4:3, 1600x1200px.
```

---

## 详情页模块Prompt

### 模块1 — 公司实力Banner

```
Company profile banner image for Alibaba.com product detail page, 1200px wide.
Full-width horizontal layout.
Left 40%: Company/factory hero image — modern facility exterior or aerial view.
Right 60%: Company credentials grid:
  - Founded year badge
  - Factory size in ㎡
  - Countries exported to
  - Key certifications row
  - Employee count
Headline: "[公司名] — Your Trusted [行业] Manufacturer Since [年份]"
Color: Deep professional blue or dark charcoal with white/gold accents.
Style: Corporate B2B marketing banner, trust-inspiring.
```

### 模块2 — 产品参数表

```
Product specification table graphic for e-commerce detail page, 1200px wide.
Clean data table design with alternating row colors (white/very light gray).
Column headers: Specification | Details
Rows listing: [从产品信息中提取的规格参数]
Left side: Product isometric or front view image.
Header: "Product Specifications" in bold.
Footer: Note area for customization options.
Style: Technical documentation meets modern e-commerce design.
Professional, easy-to-read typography.
```

### 模块3 — 细节展示

```
Product detail zoom section for e-commerce page, 1200px wide.
Grid layout: 3 or 4 detail image panels.
Each panel: Product macro photograph + callout label.
Panel subjects: [细节卖点1] / [细节卖点2] / [细节卖点3] / [细节卖点4]
Each panel has: Detail image (top 70%) + label text (bottom 30%).
Unified background: Very light gray or white.
Style: Technical product catalog, premium quality feel.
```

### 模块4 — 核心卖点

```
Key selling points feature section for B2B product listing, 1200px wide.
Layout: 3 or 4 feature cards in horizontal row.
Each card: Icon (line art style) + Bold feature title + 2-line description.
Features: [卖点1] / [卖点2] / [卖点3] / [卖点4]
Card style: Clean white cards with subtle shadow, accent color top border.
Background: Light gray or gradient.
Typography: Professional, readable, B2B appropriate.
Accent color: [类目对应主色调]
```

### 模块5 — 公司详细实力

```
Detailed company capability section for supplier profile page, 1200px wide.
Multi-section layout:
Section A: Factory photos grid (4 images) — production line, equipment, warehouse, QC lab.
Section B: R&D and technology capability highlights.
Section C: Export history world map with highlighted countries.
Section D: Quality control process flow (4-step infographic).
Style: Professional corporate brochure style, information-dense but organized.
Color: Consistent with overall listing color scheme.
```

### 模块6 — FAQ

```
FAQ section graphic for product listing page, 1200px wide.
Accordion/list style design.
Q&A pairs — 5 to 8 questions:
[从产品信息生成的常见问题]
Layout: Question in bold + answer in regular weight below.
Each Q separated by subtle divider line.
Left accent: Question number or Q icon in brand color.
Style: Clean, professional, easy to scan.
Bottom CTA: "Have More Questions? Send Us an Inquiry" button graphic.
```

---

## 按类目定制Prompt补充

> 根据品牌配置中的类目代码，为对应品类追加以下差异化描述。

### ELEC — 3C 电子

**色调**：`Tech blue, silver metallic, dark background with light product emphasis`
**场景**：`Modern office desk setup, smart home environment, tech-savvy lifestyle`
**材质展示**：`Premium aluminum alloy texture, precision engineering, circuit board detail`
**首图补充**：`Clean room or electronics assembly line background, technician in ESD-safe uniform`

```
[卖点图/场景图细节补充]
Electronic product detail photography.
Show: Precision connectors, material finish quality, technical specifications callouts.
Background: Dark charcoal or gradient tech background.
LED accent lighting to highlight product contours.
Technical spec tags with clean minimal typography.
```

### HOME — 家居家具

**色调**：`Warm neutral tones, Scandinavian white, earth tones, lifestyle warmth`
**场景**：`Modern living room, bedroom, kitchen, minimalist interior design`
**材质展示**：`Wood grain texture, fabric weave, metal finish, stone surface`
**首图补充**：`Furniture workshop or upholstery production line, craftsman at work`

```
[卖点图/场景图细节补充]
Home furniture/decor detail photography.
Show: Material texture closeup, joinery quality, surface finish detail.
Lifestyle background: Styled interior room, soft natural window light.
Warm, inviting atmosphere. Scandinavian or contemporary interior styling.
Props: Complementary decor items to create aspirational home scene.
```

### APPAREL — 服装服饰

**色调**：`Fashion-forward, clean white studio or lifestyle editorial`
**场景**：`Fashion studio, outdoor lifestyle, commercial retail environment`
**材质展示**：`Fabric weave closeup, stitching quality, zipper/button detail`
**首图补充**：`Garment factory sewing line, quality control inspector examining fabric`

```
[卖点图/场景图细节补充]
Apparel/textile detail photography.
Show: Fabric texture macro, stitching precision, hardware quality (buttons, zippers).
Flat lay or mannequin display for full garment.
Fabric drape quality on body or hanger.
Color accuracy critical — neutral background to show true color.
Size chart graphic overlay if applicable.
```

### BEAUTY — 美妆个护

**色调**：`Soft pink, gold, white, clean pharmaceutical-style or luxury cosmetic`
**场景**：`Bathroom vanity, beauty studio, spa environment, skincare routine`
**材质展示**：`Product texture (cream, liquid, powder), packaging premium finish`
**首图补充**：`Cosmetic manufacturing clean room, lab technician in white coat`

```
[卖点图/场景图细节补充]
Beauty product photography.
Show: Product texture/consistency (if applicable — swatch, application), packaging detail.
Ingredients visual if natural/organic: botanical elements, raw ingredients arranged artfully.
Soft diffused lighting, feminine and premium atmosphere.
Before/after indication area (tasteful, professional).
Certification badges: Cruelty-free, Organic, Dermatologist-tested.
```

### OUTDOOR — 户外运动

**色调**：`Adventure green, earth tones, action energy colors (orange, red)`
**场景**：`Mountain, camping site, trail, gym, sports field`
**材质展示**：`Weatherproof coating, heavy-duty stitching, technical fabric`
**首图补充**：`Outdoor gear testing facility or production line, quality stress-testing`

```
[卖点图/场景图细节补充]
Outdoor/sporting goods product photography.
Show: Durability features — reinforced stitching, waterproof coating, load-bearing hardware.
Action context: Product in use in outdoor/adventure environment.
Rugged, dynamic composition. Natural light preferred.
Technical callouts: Waterproof rating, weight capacity, material specs.
```

### INDUSTRIAL — 工业机械

**色调**：`Industrial steel gray, safety yellow, professional navy blue`
**场景**：`Factory floor, workshop, construction site, industrial application`
**材质展示**：`Metal precision, welding quality, mechanical components`
**首图补充**：`Heavy machinery production workshop, engineer in hard hat inspecting equipment`

```
[卖点图/场景图细节补充]
Industrial machinery/component product photography.
Show: Precision engineering detail — machining marks, tolerance specifications, material grade.
Technical cross-section or exploded view diagram style.
Strong directional lighting to show surface precision and finish.
Safety certification marks prominently displayed.
Scale reference (ruler, hand) to show actual size.
Technical specification overlay with dimension callouts.
```

### AUTO — 汽车配件

**色调**：`Automotive silver, carbon fiber texture, premium black`
**场景**：`Car interior/exterior install context, auto shop, racing circuit`
**材质展示**：`Metal plating, rubber seal, electronic connector detail`
**首图补充**：`Auto parts manufacturing line, quality inspector with calipers`

```
[卖点图/场景图细节补充]
Automotive parts photography.
Show: Precision fit and finish — OEM compatibility features, material quality.
Installation context: Part shown on/near vehicle for scale and fitment reference.
Surface treatment detail: Chrome plating, powder coating, anodizing.
Compatible vehicle list visual element.
```

### FOOD — 食品农产品

**色调**：`Fresh natural green, warm harvest tones, clean white food-safe`
**场景**：`Farm field, kitchen, food service environment, retail packaging`
**材质展示**：`Product freshness, texture, natural origin`
**首图补充**：`Food processing facility, quality inspector in food-safe uniform and gloves`

```
[卖点图/场景图细节补充]
Food product photography.
Show: Product freshness and quality — texture, color vibrancy, natural appearance.
Origin story visual: Farm/source environment as background.
Nutrition/ingredient callout area.
Packaging shot showing labeling, certifications (HACCP, Organic, Halal etc.).
Appetizing, clean, and food-safe visual presentation.
```

### BABY — 母婴玩具

**色调**：`Soft pastel, gentle cream, playful primary colors`
**场景**：`Nursery, playroom, outdoor play area, parent-child interaction`
**材质展示**：`Soft fabric, rounded edges, non-toxic material emphasis`
**首图补充**：`Toy/baby product safety testing facility, quality inspector with products`

```
[卖点图/场景图细节补充]
Baby/children product photography.
Show: Safety features — rounded edges, non-toxic materials, certifications (EN71, ASTM, CPSC).
Child in use (without showing child's face for privacy if needed) or parent interaction.
Soft, warm, nurturing atmosphere.
Safety certification badges prominently displayed.
Age-appropriate indicators.
```

### PET — 宠物用品

**色调**：`Playful, warm, pet-friendly natural tones`
**场景**：`Home pet environment, outdoor with pet, veterinary clean`
**材质展示**：`Pet-safe materials, durability for chewing/scratching`
**首图补充**：`Pet product manufacturing with quality control, material safety testing`

```
[卖点图/场景图细节补充]
Pet product photography.
Show: Product with adorable pet if possible, or styled pet environment.
Material safety callouts: BPA-free, food-grade, non-toxic.
Size/weight capacity indicators.
Durability features for active pets.
Warm, lifestyle-oriented atmosphere.
```

### HEALTH — 医疗健康

**色调**：`Clinical white, medical blue, reassuring professional tones`
**场景**：`Medical facility, home health use, professional healthcare setting`
**材质展示**：`Medical-grade material, precision engineering, hygiene design`
**首图补充**：`Medical device manufacturing clean room, technician in sterile uniform`

```
[卖点图/场景图细节补充]
Medical/health product photography.
Show: Precision and reliability — measurement accuracy, material quality, ergonomic design.
Professional medical context without being overly clinical.
Certification badges: CE, FDA, ISO 13485 prominently placed.
Easy-to-use feature callouts for home health users.
Trust-building, clean, professional aesthetic.
```

### GIFT — 礼品定制

**色调**：`Premium gold, festive seasonal tones, luxury packaging aesthetic`
**场景**：`Gift presentation setup, corporate gifting context, retail display`
**材质展示**：`Packaging premium, customization options, logo placement`
**首图补充**：`Gift product customization workshop, personalization process`

```
[卖点图/场景图细节补充]
Promotional gift/custom product photography.
Show: Customization options — logo placement, color variations, packaging choices.
Premium gifting presentation: ribbon, gift box, elegant arrangement.
Corporate context: Professional desk, business meeting setting.
MOQ and customization lead time callout area.
```

---

## Prompt增强技巧

1. **产品保真度**：在prompt末尾加 `Keep the product's original design, colors and branding exactly as shown in the reference image.`

2. **文字清晰度**：加 `All text must be crisp, readable, and professional. No blurry or distorted text.`

3. **留白**：加 `Leave appropriate white space — clean layout, not cluttered.`

4. **专业感**：加 `The overall feel should be suitable for a Fortune 500 B2B buyer audience.`

5. **长宽比选择**：
   - 主图：`1:1`（正方形最佳）
   - 详情页：`16:9`
   - 竖版（移动端）：`3:4`
   - 方图（社媒）：`1:1`
   - 集合图：`4:3`

6. **品类差异化**：根据品牌配置的类目代码，追加对应品类的色调/场景/材质描述（参见上方"按类目定制Prompt补充"章节）。
