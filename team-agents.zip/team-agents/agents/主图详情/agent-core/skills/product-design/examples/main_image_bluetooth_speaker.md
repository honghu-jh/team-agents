# 示例：蓝牙音箱主图B2B化设计

## 输入信息

- **产品图片**：白底蓝牙音箱正面图（JPG, 2000×2000px）
- **产品品类**：消费电子 / 蓝牙音箱
- **目标市场**：欧美为主
- **MOQ**：100 pcs
- **价格区间**：$8.50–$15.00/pc（阶梯报价）
- **交期**：25天
- **认证**：CE, RoHS, FCC, ISO 9001
- **可定制**：颜色（黑/白/蓝/红）、Logo丝印

## 需求判断

属于 **主图优化** 类型 — 将白底产品图升级为B2B采购信息图。

## 设计方案（ASCII布局）

```
┌─────────────────────────────────────────────┐
│ [顶部通栏 navy] "Bluetooth Speaker | OEM &  │
│                  Wholesale Supplier"        │
├──────────────────────┬──────────────────────┤
│                      │ [右上] 🛡 MOQ: 100   │
│   蓝牙音箱主图       │      Units (绿盾牌)   │
│   (左侧60%)          │ [右中] 4色色卡圆圈    │
│   + 参数标注箭头     │      Black/White/     │
│   → 10W Driver       │      Blue/Red        │
│   → IPX5 Waterproof  │ [右下] 阶梯报价卡    │
│   → 12h Battery      │  100–499: $15.00     │
│                      │  500–999: $11.50     │
│                      │  1000+:  $8.50       │
├──────────────────────┴──────────────────────┤
│ [底部左] CE | RoHS | FCC | ISO 9001 徽章   │
│ [底部右] ⭐4.8/5 | 200+ Clients | 2-Year   │
├─────────────────────────────────────────────┤
│ [最底通栏 navy] ✔ Free Sample | ✔ OEM Logo │
│ ✔ 25-Day Lead Time | ✔ Global Shipping     │
└─────────────────────────────────────────────┘
```

## 完整英文 Prompt

```
Transform this product image into a professional B2B procurement promotional banner.
Keep the black Bluetooth speaker as the hero product, prominently displayed in the
center-left area. White background.

Add the following B2B buyer procurement elements:

1. Top header bar in navy blue: "Bluetooth Speaker | OEM & Wholesale Supplier"

2. MOQ badge upper-left corner: Bold green shield badge "MOQ: 100 Units" with
   a factory/warehouse icon

3. Key spec callouts — 3 floating label tags pointing to different parts:
   - Pointing to speaker driver: "10W Full-Range Driver"
   - Pointing to body: "IPX5 Waterproof Rating"
   - Pointing to base: "12-Hour Battery Life"

4. Color/variant options right side: 4 small product silhouettes showing color
   variants — Black, White, Navy Blue, Red — with label "Custom Color Available"

5. Certification row bottom-left: CE | RoHS | FCC | ISO 9001 badges in a clean
   horizontal strip

6. Tiered pricing table bottom-right (clean card style):
   | Qty              | Price   |
   | 100–499 pcs      | $15.00  |
   | 500–999 pcs      | $11.50  |
   | 1000+ pcs        | $8.50   |

7. Bottom CTA strip in navy blue: "✔ Free Sample Available | ✔ OEM Logo Accepted
   | ✔ 25-Day Lead Time | ✔ Global Shipping"

8. Trust badges: ⭐4.8/5 Rating | 200+ B2B Clients | Trade Assurance |
   2-Year Warranty

Style: Clean, modern, professional. Navy blue, white, gold accent color palette.
Trustworthy B2B e-commerce feel suitable for Alibaba.com listing.
Keep the product's original design, colors and branding exactly as shown in the
reference image.
All text must be crisp, readable, and professional. No blurry or distorted text.
Leave appropriate white space — clean layout, not cluttered.
```

## 预期效果

一张1600×1200px的4:3比例横幅，白底上居中展示蓝牙音箱，周围环绕B2B采购决策信息。采购商在阿里国际站搜索结果页看到这张图时，能立即获取MOQ、价格、认证、定制能力等关键决策信息，无需点进详情页。

## ImageGen 工具调用示例

```
ImageGen(
  prompt="<上述完整英文prompt>",
  size="1024x768"
)
```
