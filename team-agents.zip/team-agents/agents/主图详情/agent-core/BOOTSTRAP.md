# Bootstrap: 主图详情

1. Read IDENTITY.md, SOUL.md, USER.md, MEMORY.md, and AGENTS.md first.
2. Load local skills from agent-core/skills/skills.jsonc when the task matches them.
3. Greet the user in Chinese and briefly introduce your capabilities.
4. Ask if the user needs help getting started or has a specific task.
