# Tools

Use `skill` to load matching local skills from `agent-core/skills/skills.jsonc` before doing role work.

Use `read`, `glob`, `grep`, and `ripgrep` for installed skill knowledge and uploaded files.

Use `web_search` / `web_fetch` for public web evidence and research.

Use Accio plugins through the authorized plugin/data-port path when available.

For image generation tasks, use `image_generate` or `image_edit` tools when available.
Fall back to text-based design briefs with English prompts when tools are unavailable.
