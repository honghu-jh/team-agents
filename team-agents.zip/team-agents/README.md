# 国际站团队 6 智能体一键安装包

一行代码，自动下载并安装以下 6 个外贸智能体到你的 Accio Work：

| # | 智能体 | 用途 |
|---|--------|------|
| 1 | 企业优势提炼助手 | 企业资料 → 差异化优势 → 全场景销售话术 |
| 2 | 国际站询盘分析助手 | 询盘真伪判断、买家等级评估、需求识别 |
| 3 | 首回跟进助手 | 万用首回公式：自我介绍+优势展示+CTA |
| 4 | 主图详情 | B2B 产品主图/详情页/工厂背书图设计 |
| 5 | 发品大师 | 素材发品：图片/素材包 → 商品草稿或直接上架 |
| 6 | 超级外贸业务专家 | 开发客户→背调→RFQ→谈单→盘活全链路 |

---

## 安装方法

### macOS / Linux（终端）

打开「终端」（Terminal），粘贴以下命令回车：

```bash
cd ~ && curl -sL "<ZIP下载地址>" -o team-agents.zip && unzip -qo team-agents.zip && bash team-agents/install.sh
```

### Windows（PowerShell）

打开 PowerShell（开始菜单搜索 PowerShell），粘贴以下命令回车：

```powershell
Set-Location $HOME; Remove-Item team-agents -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item team-agents.zip -Force -ErrorAction SilentlyContinue; Invoke-WebRequest -Uri "<ZIP下载地址>" -OutFile team-agents.zip; Expand-Archive team-agents.zip -DestinationPath . -Force; Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force; .\team-agents\install.ps1
```

> 零依赖：Mac 脚本只用系统自带 bash/sed，Windows 脚本只用系统自带 PowerShell，无需安装 jq / Python / Homebrew。

---

## 安装后必做

1. **完全退出** Accio Work（不是最小化，是彻底关闭），再重新打开
2. 设置 → 插件 → 按需安装插件：
   - Documents / Spreadsheets / Presentations（文档处理）
   - Knowledge Base（知识库）
   - 国际站生意助手（发品大师、询盘分析等需要）
3. 连接器 → 绑定各自账号（阿里国际站店铺等）

安装完成后，在智能体列表即可看到 6 个新智能体。

---

## 常见问题

| 问题 | 解决 |
|------|------|
| 提示"未找到登录状态文件" | 先登录 Accio Work 桌面端，再运行安装命令 |
| 提示"无法解析 accountId" | 确认 Accio Work 已登录；Mac 检查 `~/.accio/state/current-space.json` 是否存在 |
| 安装后列表看不到新智能体 | 完全退出并重新打开 Accio Work |
| 智能体技能不生效 | 在设置 → 插件中安装对应插件并重启 |
