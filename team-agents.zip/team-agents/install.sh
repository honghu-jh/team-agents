#!/bin/bash
# ============================================================
#  国际站团队 6 智能体一键安装（macOS / Linux）
#  零依赖：纯 bash + sed，不需要 jq / python3 / brew
# ============================================================
# 一次性解析脚本绝对路径（兼容相对/绝对两种调用方式）
SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(pwd)"
fi
cd "$SCRIPT_DIR"

echo "=============================================="
echo "  国际站团队 6 智能体一键安装 (Mac / Linux)"
echo "=============================================="

# ---- 1. 定位 current-space.json ----
CURRENT_SPACE=""
for candidate in \
    "$HOME/.accio/state/current-space.json" \
    "$HOME/Library/Application Support/accio/state/current-space.json" \
    "$HOME/Library/Application Support/Accio/state/current-space.json" \
    "$HOME/Library/Application Support/Accio Work/state/current-space.json"
do
    [ -f "$candidate" ] && CURRENT_SPACE="$candidate" && break
done

if [ -z "$CURRENT_SPACE" ]; then
    # 全局兜底搜索
    CURRENT_SPACE=$(find "$HOME" -name "current-space.json" -maxdepth 8 \
        ! -path "*/Trash/*" 2>/dev/null | head -1 || true)
fi

if [ -z "$CURRENT_SPACE" ]; then
    echo "[错误] 未找到 Accio Work 登录状态文件（current-space.json）。"
    echo "       请先登录 Accio Work 桌面端，然后重试。"
    read -n 1 -s -r -p "按任意键退出..."
    echo
    exit 1
fi
echo "[1/4] 已定位登录状态: $CURRENT_SPACE"

# ---- 2. 解析 accountId（纯 sed，无 jq 依赖）----
ACCOUNT_ID=$(grep -o '"accountId"[[:space:]]*:[[:space:]]*"[^"]*"' "$CURRENT_SPACE" \
    | head -1 | sed 's/.*"\([^"]*\)"$/\1/')

if [ -z "$ACCOUNT_ID" ]; then
    echo "[错误] 无法从登录状态解析 accountId。"
    echo "       请确认已登录 Accio Work，并检查文件内容: $CURRENT_SPACE"
    read -n 1 -s -r -p "按任意键退出..."
    echo
    exit 1
fi
echo "[2/4] 当前账号 accountId: $ACCOUNT_ID"

# ---- 3. 定位 agents 根目录 ----
ACCOUNTS_ROOT="$HOME/.accio/accounts"
AGENTS_ROOT=""
for cand in "$ACCOUNTS_ROOT/$ACCOUNT_ID/agents" "$ACCOUNTS_ROOT/${ACCOUNT_ID}_"*"/agents"; do
    [ -d "$cand" ] && AGENTS_ROOT="$cand" && break
done
if [ -z "$AGENTS_ROOT" ]; then
    AGENTS_ROOT="$ACCOUNTS_ROOT/$ACCOUNT_ID/agents"
fi
mkdir -p "$AGENTS_ROOT"
echo "[3/4] 智能体安装目录: $AGENTS_ROOT"

# ---- 4. 逐智能体安装（复制 + sed 模板替换）----
PKG_AGENTS="$SCRIPT_DIR/agents"

if [ ! -f "$PKG_AGENTS/manifest.json" ]; then
    echo "[错误] 缺少 agents/manifest.json，安装包不完整。"
    echo "       请确认解压后的文件夹结构为 team-agents/（内含 install.sh 和 agents/ 文件夹）。"
    read -n 1 -s -r -p "按任意键退出..."
    echo
    exit 1
fi

# 读取 manifest 中的智能体目录名（用 sed/grep 解析简单 JSON）
AGENT_DIRS=$(grep -o '"dir"[[:space:]]*:[[:space:]]*"[^"]*"' "$PKG_AGENTS/manifest.json" \
    | sed 's/.*"dir"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/')

COUNT=0
while IFS= read -r AGENT_DIR; do
    [ -z "$AGENT_DIR" ] && continue
    # 从模板中读取 agent id（profile 模板内的 "id" 字段）
    TMPL_FILE="$PKG_AGENTS/$AGENT_DIR/profile.jsonc.template"
    [ ! -f "$TMPL_FILE" ] && continue
    AID=$(grep -o '"id"[[:space:]]*:[[:space:]]*"[^"]*"' "$TMPL_FILE" \
        | head -1 | sed 's/.*"id"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/')
    [ -z "$AID" ] && continue

    # 复制 agent-core
    SRC_DIR="$PKG_AGENTS/$AGENT_DIR/agent-core"
    DST_DIR="$AGENTS_ROOT/$AID/agent-core"
    if [ -d "$DST_DIR" ]; then
        rm -rf "$DST_DIR"
    fi
    mkdir -p "$(dirname "$DST_DIR")"
    cp -R "$SRC_DIR" "$DST_DIR"

    # 生成 profile.jsonc
    sed "s/__ACCOUNT_ID__/$ACCOUNT_ID/g" "$TMPL_FILE" > "$AGENTS_ROOT/$AID/profile.jsonc"

    # 生成 skills.jsonc
    STMPL="$PKG_AGENTS/$AGENT_DIR/skills.jsonc.template"
    if [ -f "$STMPL" ]; then
        mkdir -p "$DST_DIR/skills"
        sed -e "s|__AGENTS_ROOT__|$AGENTS_ROOT|g" -e "s|__AGENT_ID__|$AID|g" \
            "$STMPL" > "$DST_DIR/skills/skills.jsonc"
    fi

    COUNT=$((COUNT+1))
    echo "  已安装: $AGENT_DIR"
done <<< "$AGENT_DIRS"

if [ "$COUNT" -eq 0 ]; then
    echo "[错误] 未找到可安装的智能体，请检查安装包完整性。"
    read -n 1 -s -r -p "按任意键退出..."
    echo
    exit 1
fi

echo "[4/4] 安装完成，共 $COUNT 个智能体"
echo ""
echo "=============================================="
echo "  安装完成！请完全退出并重新打开 Accio Work"
echo "=============================================="
read -n 1 -s -r -p "按任意键关闭窗口..."
echo
