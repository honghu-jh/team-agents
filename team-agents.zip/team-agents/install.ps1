﻿# 国际站团队 6 智能体一键安装（Windows PowerShell）
# 编码：UTF-8 with BOM
# 零依赖：仅用系统自带 PowerShell，无需 Python

$ErrorActionPreference = "Stop"

Write-Host "=============================================="
Write-Host "  国际站团队 6 智能体一键安装 (Windows)"
Write-Host "=============================================="

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- 1. 定位 current-space.json ----
$CURRENT_SPACE = ""
$candidates = @(
    "$env:USERPROFILE\.accio\state\current-space.json",
    "$env:APPDATA\accio\state\current-space.json",
    "$env:APPDATA\Accio\state\current-space.json",
    "$env:APPDATA\Accio Work\state\current-space.json",
    "$env:LOCALAPPDATA\accio\state\current-space.json"
)
foreach ($c in $candidates) {
    if (Test-Path $c) { $CURRENT_SPACE = $c; break }
}
if (-not $CURRENT_SPACE) {
    $found = Get-ChildItem -Path $env:USERPROFILE -Filter "current-space.json" -Recurse -Depth 8 -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "Trash" } | Select-Object -First 1
    if ($found) { $CURRENT_SPACE = $found.FullName }
}
if (-not $CURRENT_SPACE) {
    Write-Host "[错误] 未找到 Accio Work 登录状态文件（current-space.json）。请先登录 Accio Work 桌面端后重试。" -ForegroundColor Red
    Read-Host "按回车退出"
    exit 1
}
Write-Host "[1/4] 已定位登录状态: $CURRENT_SPACE"

# ---- 2. 解析 accountId ----
$ACCOUNT_ID = ""
try {
    $spaceText = [System.IO.File]::ReadAllText($CURRENT_SPACE)
    $space = $spaceText | ConvertFrom-Json
    $ACCOUNT_ID = [string]$space.accountId
} catch {
    $ACCOUNT_ID = ""
}
if (-not $ACCOUNT_ID) {
    Write-Host "[错误] 无法解析 accountId。" -ForegroundColor Red
    Read-Host "按回车退出"
    exit 1
}
Write-Host "[2/4] 当前账号 accountId: $ACCOUNT_ID"

# ---- 3. 定位 agents 根目录 ----
$ACCOUNTS_ROOT = Join-Path $env:USERPROFILE ".accio\accounts"
$AGENTS_ROOT = Join-Path $ACCOUNTS_ROOT "$ACCOUNT_ID\agents"
if (-not (Test-Path $AGENTS_ROOT)) {
    $dirs = Get-ChildItem -Path $ACCOUNTS_ROOT -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "$ACCOUNT_ID*" }
    foreach ($d in $dirs) {
        $trial = Join-Path $d.FullName "agents"
        if (Test-Path $trial) { $AGENTS_ROOT = $trial; break }
    }
}
New-Item -ItemType Directory -Force -Path $AGENTS_ROOT | Out-Null
Write-Host "[3/4] 智能体安装目录: $AGENTS_ROOT"

# ---- 4. 逐智能体安装 ----
$manifestPath = Join-Path $scriptDir "agents\manifest.json"
if (-not (Test-Path $manifestPath)) {
    Write-Host "[错误] 缺少 agents\manifest.json，安装包不完整。" -ForegroundColor Red
    Read-Host "按回车退出"
    exit 1
}
$manifestText = [System.IO.File]::ReadAllText($manifestPath)
$manifest = $manifestText | ConvertFrom-Json

$count = 0
foreach ($ag in $manifest) {
    $aid = [string]$ag.id
    $name = [string]$ag.name
    $srcDir = Join-Path $scriptDir "agents\$($ag.dir)\agent-core"
    $dstDir = Join-Path $AGENTS_ROOT "$aid\agent-core"

    if (Test-Path $dstDir) { Remove-Item -Recurse -Force $dstDir }
    Copy-Item -Recurse -Force $srcDir $dstDir

    # profile.jsonc：注入 accountId
    $tmpl = Join-Path $scriptDir "agents\$($ag.dir)\profile.jsonc.template"
    if (Test-Path $tmpl) {
        $body = [System.IO.File]::ReadAllText($tmpl)
        $body = $body.Replace("__ACCOUNT_ID__", $ACCOUNT_ID)
        [System.IO.File]::WriteAllText(
            (Join-Path $AGENTS_ROOT "$aid\profile.jsonc"), $body,
            (New-Object System.Text.UTF8Encoding($true)))
    }

    # skills.jsonc：注入真实 installPath
    $stmpl = Join-Path $scriptDir "agents\$($ag.dir)\skills.jsonc.template"
    if (Test-Path $stmpl) {
        $sbody = [System.IO.File]::ReadAllText($stmpl)
        $sbody = $sbody.Replace("__AGENTS_ROOT__", $AGENTS_ROOT).Replace("__AGENT_ID__", $aid)
        $skillsDir = Join-Path $dstDir "skills"
        New-Item -ItemType Directory -Force -Path $skillsDir | Out-Null
        [System.IO.File]::WriteAllText(
            (Join-Path $skillsDir "skills.jsonc"), $sbody,
            (New-Object System.Text.UTF8Encoding($true)))
    }

    $count++
    Write-Host "  已安装: $name"
}

if ($count -eq 0) {
    Write-Host "[错误] 未找到可安装的智能体。" -ForegroundColor Red
    Read-Host "按回车退出"
    exit 1
}

Write-Host "[4/4] 安装完成，共 $count 个智能体"
Write-Host ""
Write-Host "=============================================="
Write-Host "  安装完成！请完全退出并重新打开 Accio Work"
Write-Host "=============================================="
Read-Host "按回车退出"
